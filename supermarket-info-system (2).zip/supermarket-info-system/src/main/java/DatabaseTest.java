package com.supermarket;

import com.supermarket.model.User;
import com.supermarket.model.UserRole;
import com.supermarket.service.UserService;
import com.supermarket.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class DatabaseTest {
    public static void main(String[] args) {
        System.out.println("=== ТЕСТ ПОДКЛЮЧЕНИЯ К БАЗЕ ДАННЫХ ===");

        try {
            // Тест 1: Проверка подключения Hibernate
            System.out.println("1. Тест подключения Hibernate...");
            Session session = HibernateUtil.getSessionFactory().openSession();
            System.out.println("✅ Подключение успешно!");
            session.close();

            // Тест 2: Создание таблицы и добавление тестового пользователя
            System.out.println("\n2. Создание тестового пользователя...");
            UserService userService = new UserService();

            // Создаем админа (если еще нет)
            if (userService.findByUsername("admin").isEmpty()) {
                User admin = userService.registerUser(
                        "admin",
                        "admin123",
                        UserRole.ADMIN,
                        "Администратор Системы",
                        "admin@supermarket.local"
                );
                System.out.println("✅ Создан администратор: " + admin.getUsername());
            } else {
                System.out.println("ℹ️ Администратор уже существует");
            }

            // Тест 3: Получение всех пользователей
            System.out.println("\n3. Получение всех пользователей...");
            userService.getAllUsers().forEach(user ->
                    System.out.println("   - " + user.getUsername() + " (" + user.getRole() + ")")
            );

            // Тест 4: Аутентификация
            System.out.println("\n4. Тест аутентификации...");
            var authResult = userService.authenticate("admin", "admin123");
            if (authResult.isPresent()) {
                System.out.println("✅ Аутентификация успешна!");
                System.out.println("   Пользователь: " + authResult.get().getFullName());
            } else {
                System.out.println("❌ Ошибка аутентификации");
            }

            System.out.println("\n=== ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО ===");

        } catch (Exception e) {
            System.err.println("❌ ОШИБКА: " + e.getMessage());
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}