package com.supermarket.service;

import com.supermarket.model.Category;
import com.supermarket.model.Product;
import com.supermarket.dao.ProductDao;
import com.supermarket.dao.CategoryDao;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class StatisticsService {
    private final ProductDao productDao = new ProductDao();
    private final CategoryDao categoryDAO = new CategoryDao();

    /**
     * Общее количество товаров в системе
     */
    public int getTotalProducts() {
        List<Product> products = productDao.findAll();
        int count = products.size();
        System.out.println("DEBUG: getTotalProducts() = " + count);
        return count;
    }

    /**
     * Общая стоимость всех товаров на складе
     */
    public double getTotalInventoryValue() {
        List<Product> products = productDao.findAll();
        double value = products.stream()
                .mapToDouble(p -> {
                    BigDecimal price = p.getPrice();
                    Integer quantity = p.getQuantity();
                    return (price != null ? price.doubleValue() : 0.0) *
                            (quantity != null ? quantity : 0);
                })
                .sum();
        System.out.println("DEBUG: getTotalInventoryValue() = " + value);
        return value;
    }

    /**
     * Количество товаров по категориям (исправленная версия)
     */
    public Map<String, Integer> getProductsByCategory() {
        System.out.println("=== DEBUG: getProductsByCategory() ===");
        Map<String, Integer> result = new HashMap<>();

        List<Product> products = productDao.findAll();
        System.out.println("Всего товаров для анализа: " + products.size());

        // Подсчитываем товары по категориям
        for (Product product : products) {
            String categoryName = "Без категории";
            if (product.getCategory() != null && product.getCategory().getName() != null) {
                categoryName = product.getCategory().getName();
            }

            result.put(categoryName, result.getOrDefault(categoryName, 0) + 1);
        }

        System.out.println("Результат: " + result);
        return result;
    }

    /**
     * Товары с низким запасом (ниже минимального уровня)
     */
    public List<Product> getLowStockProducts() {
        List<Product> lowStock = productDao.findAll().stream()
                .filter(p -> p.getMinStockLevel() != null &&
                        p.getQuantity() < p.getMinStockLevel())
                .collect(Collectors.toList());
        System.out.println("DEBUG: getLowStockProducts() = " + lowStock.size() + " товаров");
        return lowStock;
    }

    /**
     * Статистика по категориям (исправленная)
     */
    public Map<String, Map<String, Object>> getCategoryStatistics() {
        System.out.println("=== DEBUG: getCategoryStatistics() ===");
        Map<String, Map<String, Object>> stats = new HashMap<>();

        List<Category> categories = categoryDAO.findAll();
        System.out.println("Всего категорий: " + categories.size());

        for (Category category : categories) {
            System.out.println("Анализ категории: " + category.getName());

            // Используем новый метод findByCategory
            List<Product> categoryProducts = productDao.findByCategory(category.getId());
            System.out.println("  Товаров в категории: " + categoryProducts.size());

            Map<String, Object> categoryStats = new HashMap<>();
            categoryStats.put("count", categoryProducts.size());

            double totalValue = categoryProducts.stream()
                    .mapToDouble(p -> {
                        BigDecimal price = p.getPrice();
                        Integer quantity = p.getQuantity();
                        return (price != null ? price.doubleValue() : 0.0) *
                                (quantity != null ? quantity : 0);
                    })
                    .sum();
            categoryStats.put("totalValue", totalValue);

            double avgPrice = categoryProducts.stream()
                    .mapToDouble(p -> p.getPrice() != null ? p.getPrice().doubleValue() : 0.0)
                    .average()
                    .orElse(0.0);
            categoryStats.put("avgPrice", avgPrice);

            // Добавляем минимальное и максимальное количество
            int minQuantity = categoryProducts.stream()
                    .mapToInt(Product::getQuantity)
                    .min()
                    .orElse(0);
            categoryStats.put("minQuantity", minQuantity);

            int maxQuantity = categoryProducts.stream()
                    .mapToInt(Product::getQuantity)
                    .max()
                    .orElse(0);
            categoryStats.put("maxQuantity", maxQuantity);

            System.out.println("  Итог: count=" + categoryProducts.size() +
                    ", totalValue=" + totalValue +
                    ", avgPrice=" + avgPrice);

            stats.put(category.getName(), categoryStats);
        }

        // Добавляем товары без категории
        List<Product> allProducts = productDao.findAll();
        List<Product> noCategoryProducts = allProducts.stream()
                .filter(p -> p.getCategory() == null)
                .collect(Collectors.toList());

        if (!noCategoryProducts.isEmpty()) {
            Map<String, Object> noCategoryStats = new HashMap<>();
            noCategoryStats.put("count", noCategoryProducts.size());

            double totalValue = noCategoryProducts.stream()
                    .mapToDouble(p -> {
                        BigDecimal price = p.getPrice();
                        Integer quantity = p.getQuantity();
                        return (price != null ? price.doubleValue() : 0.0) *
                                (quantity != null ? quantity : 0);
                    })
                    .sum();
            noCategoryStats.put("totalValue", totalValue);

            stats.put("Без категории", noCategoryStats);
        }

        if (stats.isEmpty()) {
            System.out.println("ВНИМАНИЕ: Статистика по категориям пуста!");
        }

        return stats;
    }

    /**
     * Количество активных/неактивных товаров
     */
    public Map<String, Long> getProductActivityStats() {
        System.out.println("=== DEBUG: getProductActivityStats() ===");

        List<Product> products = productDao.findAll();
        System.out.println("Всего товаров: " + products.size());

        long active = products.stream()
                .filter(Product::isActive)
                .count();
        long inactive = products.size() - active;

        System.out.println("Активные товары: " + active);
        System.out.println("Неактивные товары: " + inactive);

        Map<String, Long> stats = new HashMap<>();
        stats.put("Активные", active);
        stats.put("Неактивные", inactive);

        System.out.println("Результат статистики: " + stats);
        return stats;
    }

    /**
     * Средняя цена товаров
     */
    public double getAverageProductPrice() {
        List<Product> products = productDao.findAll();
        double avg = products.stream()
                .mapToDouble(p -> p.getPrice() != null ? p.getPrice().doubleValue() : 0.0)
                .average()
                .orElse(0.0);
        System.out.println("DEBUG: getAverageProductPrice() = " + avg);
        return avg;
    }

    /**
     * Общее количество товаров на складе
     */
    public int getTotalProductQuantity() {
        int total = productDao.findAll().stream()
                .mapToInt(Product::getQuantity)
                .sum();
        System.out.println("DEBUG: getTotalProductQuantity() = " + total);
        return total;
    }

    /**
     * Распределение товаров по статусу запаса
     */
    public Map<String, Integer> getStockStatusDistribution() {
        System.out.println("=== DEBUG: getStockStatusDistribution() ===");
        List<Product> products = productDao.findAll();

        int outOfStock = (int) products.stream()
                .filter(p -> p.getQuantity() == 0)
                .count();

        int lowStock = (int) products.stream()
                .filter(p -> p.getMinStockLevel() != null &&
                        p.getQuantity() > 0 &&
                        p.getQuantity() < p.getMinStockLevel())
                .count();

        int normalStock = (int) products.stream()
                .filter(p -> p.getMinStockLevel() != null &&
                        p.getQuantity() >= p.getMinStockLevel())
                .count();

        int noStockLevel = (int) products.stream()
                .filter(p -> p.getMinStockLevel() == null && p.getQuantity() > 0)
                .count();

        Map<String, Integer> distribution = new HashMap<>();
        distribution.put("Нет в наличии", outOfStock);
        distribution.put("Низкий запас", lowStock);
        distribution.put("Нормальный запас", normalStock);
        distribution.put("Без уровня запаса", noStockLevel);

        System.out.println("Распределение запасов: " + distribution);
        return distribution;
    }

    /**
     * Самые дорогие товары (топ N)
     */
    public List<Product> getMostExpensiveProducts(int limit) {
        List<Product> expensive = productDao.findAll().stream()
                .sorted((p1, p2) -> {
                    BigDecimal price1 = p1.getPrice();
                    BigDecimal price2 = p2.getPrice();
                    BigDecimal p1Value = price1 != null ? price1 : BigDecimal.ZERO;
                    BigDecimal p2Value = price2 != null ? price2 : BigDecimal.ZERO;
                    return p2Value.compareTo(p1Value);
                })
                .limit(limit)
                .collect(Collectors.toList());
        System.out.println("DEBUG: getMostExpensiveProducts(" + limit + ") = " + expensive.size() + " товаров");
        return expensive;
    }

    /**
     * Метод для полной проверки статистики
     */
    public void debugAllStatistics() {
        System.out.println("\n=== ПОЛНАЯ ОТЛАДКА СТАТИСТИКИ ===");
        System.out.println("1. Всего товаров: " + getTotalProducts());
        System.out.println("2. Общая стоимость: " + getTotalInventoryValue());
        System.out.println("3. Активность: " + getProductActivityStats());
        System.out.println("4. По категориям: " + getProductsByCategory());
        System.out.println("5. Статистика категорий: " + getCategoryStatistics());
        System.out.println("6. Средняя цена: " + getAverageProductPrice());
        System.out.println("7. Общее количество: " + getTotalProductQuantity());
        System.out.println("8. Распределение запасов: " + getStockStatusDistribution());
        System.out.println("=== КОНЕЦ ОТЛАДКИ ===\n");
    }

    /**
     * НОВЫЙ МЕТОД: Стоимость по категориям для столбчатой диаграммы
     */
    public Map<String, Double> getValueByCategory() {
        System.out.println("=== DEBUG: getValueByCategory() ===");
        return productDao.getTotalValueByCategory();
    }
}