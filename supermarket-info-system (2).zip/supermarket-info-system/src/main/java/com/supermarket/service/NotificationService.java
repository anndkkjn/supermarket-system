package com.supermarket.service;

import com.supermarket.dao.ProductDao;
import com.supermarket.model.Product;
import javafx.application.Platform;
import javafx.scene.control.Alert;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class NotificationService {

    private final ProductDao productDao;

    public NotificationService() {
        this.productDao = new ProductDao();
    }

    /**
     * Проверка низких остатков
     */
    public List<Product> checkLowStock() {
        List<Product> lowStockProducts = productDao.findLowStock();

        if (!lowStockProducts.isEmpty()) {
            Platform.runLater(() -> {
                StringBuilder message = new StringBuilder();
                message.append("⚠️ ТОВАРЫ С НИЗКИМ ЗАПАСОМ:\n\n");
                for (Product p : lowStockProducts) {
                    message.append(String.format("• %s (осталось: %d, мин: %d)\n",
                            p.getName(), p.getQuantity(), p.getMinStockLevel()));
                }
                message.append("\nРекомендуется пополнить запасы.");

                showAlert("Уведомление: низкий запас", message.toString(), Alert.AlertType.WARNING);
            });
        }

        return lowStockProducts;
    }

    /**
     * Проверка срока годности
     */
    public List<Product> checkExpiringProducts() {
        List<Product> allProducts = productDao.findAll();
        List<Product> expiringProducts = new ArrayList<>();

        for (Product product : allProducts) {
            if (product.getExpirationDate() != null) {
                long daysUntilExpiration = ChronoUnit.DAYS.between(LocalDate.now(), product.getExpirationDate());
                if (daysUntilExpiration >= 0 && daysUntilExpiration <= 7) {
                    expiringProducts.add(product);
                }
            }
        }

        if (!expiringProducts.isEmpty()) {
            Platform.runLater(() -> {
                StringBuilder message = new StringBuilder();
                message.append("📅 ТОВАРЫ С ИСТЕКАЮЩИМ СРОКОМ ГОДНОСТИ:\n\n");

                for (Product p : expiringProducts) {
                    long daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), p.getExpirationDate());
                    message.append(String.format("• %s (истекает: %s, осталось дней: %d)\n",
                            p.getName(), p.getExpirationDate(), daysLeft));
                }
                message.append("\nРекомендуется продать в первую очередь.");

                showAlert("Уведомление: срок годности", message.toString(), Alert.AlertType.WARNING);
            });
        }

        return expiringProducts;
    }

    /**
     * Проверка просроченных товаров
     */
    public List<Product> checkExpiredProducts() {
        List<Product> allProducts = productDao.findAll();
        List<Product> expiredProducts = new ArrayList<>();

        for (Product product : allProducts) {
            if (product.getExpirationDate() != null &&
                    product.getExpirationDate().isBefore(LocalDate.now())) {
                expiredProducts.add(product);
            }
        }

        if (!expiredProducts.isEmpty()) {
            Platform.runLater(() -> {
                StringBuilder message = new StringBuilder();
                message.append("❌ ПРОСРОЧЕННЫЕ ТОВАРЫ:\n\n");

                for (Product p : expiredProducts) {
                    message.append(String.format("• %s (истек: %s)\n",
                            p.getName(), p.getExpirationDate()));
                }
                message.append("\nНЕОБХОДИМО УДАЛИТЬ ИЗ ПРОДАЖИ!");

                showAlert("ВНИМАНИЕ: просроченные товары", message.toString(), Alert.AlertType.ERROR);
            });
        }

        return expiredProducts;
    }

    /**
     * Проверка товаров для автоматического заказа
     */
    public List<Product> checkAutoOrderNeeds() {
        List<Product> lowStockProducts = productDao.findLowStock();
        List<Product> needsOrder = new ArrayList<>();

        for (Product product : lowStockProducts) {
            if (shouldCreateAutoOrder(product)) {
                needsOrder.add(product);
            }
        }

        if (!needsOrder.isEmpty()) {
            Platform.runLater(() -> {
                StringBuilder message = new StringBuilder();
                message.append("📦 РЕКОМЕНДУЕМЫЕ ЗАКАЗЫ:\n\n");

                for (Product p : needsOrder) {
                    int orderQuantity = calculateOrderQuantity(p);
                    message.append(String.format("• %s (осталось: %d, заказать: %d шт.)\n",
                            p.getName(), p.getQuantity(), orderQuantity));
                }
                message.append("\nДля автоматического заказа обратитесь к поставщику.");

                showAlert("Рекомендация: автоматический заказ", message.toString(), Alert.AlertType.INFORMATION);
            });
        }

        return needsOrder;
    }

    private boolean shouldCreateAutoOrder(Product product) {
        return product.getQuantity() < (product.getMinStockLevel() != null ?
                product.getMinStockLevel() * 0.3 : 3);
    }

    private int calculateOrderQuantity(Product product) {
        if (product.getMaxStockLevel() != null) {
            return product.getMaxStockLevel() - product.getQuantity();
        } else if (product.getMinStockLevel() != null) {
            return product.getMinStockLevel() * 2;
        } else {
            return 10;
        }
    }

    /**
     * Выполнить все проверки
     */
    public void performAllChecks() {
        System.out.println("=== ВЫПОЛНЕНИЕ ВСЕХ ПРОВЕРОК УВЕДОМЛЕНИЙ ===");

        List<Product> lowStock = checkLowStock();
        List<Product> expiring = checkExpiringProducts();
        List<Product> expired = checkExpiredProducts();
        List<Product> needsOrder = checkAutoOrderNeeds();

        // Сводка в консоль
        System.out.println("Результаты проверок:");
        System.out.println("- Товары с низким запасом: " + lowStock.size());
        System.out.println("- Товары с истекающим сроком: " + expiring.size());
        System.out.println("- Просроченные товары: " + expired.size());
        System.out.println("- Требуют заказа: " + needsOrder.size());
        System.out.println("=== ПРОВЕРКИ ЗАВЕРШЕНЫ ===");
    }

    /**
     * Получить краткую сводку уведомлений
     */
    public String getNotificationsSummary() {
        List<Product> lowStock = productDao.findLowStock();

        int expiringCount = 0;
        int expiredCount = 0;
        List<Product> allProducts = productDao.findAll();

        for (Product p : allProducts) {
            if (p.getExpirationDate() != null) {
                if (p.getExpirationDate().isBefore(LocalDate.now())) {
                    expiredCount++;
                } else if (ChronoUnit.DAYS.between(LocalDate.now(), p.getExpirationDate()) <= 7) {
                    expiringCount++;
                }
            }
        }

        StringBuilder summary = new StringBuilder();
        summary.append("📊 СВОДКА УВЕДОМЛЕНИЙ:\n\n");

        if (lowStock.isEmpty() && expiringCount == 0 && expiredCount == 0) {
            summary.append("✅ Все в порядке!\nНет критических уведомлений.");
        } else {
            if (!lowStock.isEmpty()) {
                summary.append("⚠️ Низкий запас: ").append(lowStock.size()).append(" товаров\n");
            }
            if (expiringCount > 0) {
                summary.append("📅 Истекает срок: ").append(expiringCount).append(" товаров\n");
            }
            if (expiredCount > 0) {
                summary.append("❌ Просрочено: ").append(expiredCount).append(" товаров\n");
            }
        }

        return summary.toString();
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.setResizable(true);
            alert.getDialogPane().setPrefWidth(500);
            alert.showAndWait();
        });
    }
}