package com.supermarket.service;

import com.supermarket.dao.UserDao;
import com.supermarket.model.User;
import com.supermarket.model.UserRole;
import org.mindrot.jbcrypt.BCrypt;

import java.util.List;
import java.util.Optional;

public class UserService {
    private final UserDao userDao = new UserDao();

    // Регистрация нового пользователя
    public User registerUser(String username, String password, UserRole role,
                             String fullName, String email) {

        if (userDao.usernameExists(username)) {
            throw new IllegalArgumentException("Пользователь с таким именем уже существует");
        }

        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(hashedPassword);
        user.setRole(role);
        user.setFullName(fullName);
        user.setEmail(email);

        userDao.save(user);
        return user;
    }

    // Аутентификация
    public Optional<User> authenticate(String username, String password) {
        Optional<User> userOpt = userDao.findByUsername(username);

        System.out.println("DEBUG authenticate: Пользователь " + username +
                " найден: " + userOpt.isPresent());

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            System.out.println("DEBUG: Хэш пароля из БД: " + user.getPasswordHash());
            System.out.println("DEBUG: Активен: " + user.getIsActive());

            try {
                // Проверяем пароль
                boolean passwordMatches = BCrypt.checkpw(password, user.getPasswordHash());
                System.out.println("DEBUG: Пароль совпадает: " + passwordMatches);

                if (passwordMatches && Boolean.TRUE.equals(user.getIsActive())) {
                    return Optional.of(user);
                }
            } catch (Exception e) {
                System.err.println("DEBUG: Ошибка BCrypt: " + e.getMessage());
            }
        }

        return Optional.empty();
    }
    // Получение всех пользователей
    public List<User> getAllUsers() {
        return userDao.findAll();
    }

    // Обновление пользователя
    public void updateUser(User user) {
        userDao.update(user);
    }

    // Метод для обновления пароля
    public void updatePassword(Long userId, String newPassword) {
        User user = userDao.findById(userId);
        if (user != null) {
            String hashedPassword = BCrypt.hashpw(newPassword, BCrypt.gensalt());
            user.setPasswordHash(hashedPassword);
            userDao.update(user);
        } else {
            throw new IllegalArgumentException("Пользователь не найден");
        }
    }

    // Метод для сброса пароля
    public void resetPassword(Long userId, String defaultPassword) {
        updatePassword(userId, defaultPassword);
    }
    // Удаление пользователя
    public void deleteUser(Long userId) {
        userDao.deleteById(userId);
    }

    // Поиск по имени
    public Optional<User> findByUsername(String username) {
        return userDao.findByUsername(username);
    }
}