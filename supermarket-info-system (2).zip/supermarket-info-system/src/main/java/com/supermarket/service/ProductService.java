package com.supermarket.service;

import com.supermarket.dao.ProductDao;
import com.supermarket.model.Product;
import java.util.List;

public class ProductService {
    private final ProductDao productDao = new ProductDao();

    // Метод для сохранения/обновления товара
    public void saveProduct(Product product) {
        if (product.getId() == null) {
            productDao.save(product);
        } else {
            productDao.update(product);
        }
    }

    // Метод для создания нового товара
    public void createProduct(Product product) {
        productDao.save(product);
    }

    // Метод для обновления существующего товара
    public void updateProduct(Product product) {
        productDao.update(product);
    }

    // Метод для удаления товара
    public void deleteProduct(Long id) {
        productDao.deleteById(id);
    }

    // Метод для получения товара по ID
    public Product getProductById(Long id) {
        return productDao.findById(id);
    }

    // Метод для получения всех товаров
    public List<Product> getAllProducts() {
        return productDao.findAll();
    }

    // Метод для поиска товаров по имени (исправленный)
    public List<Product> searchProducts(String query) {
        // Используем метод searchByName вместо findByName
        return productDao.searchByName(query);
    }

    // Метод для получения товаров с низким запасом
    public List<Product> getLowStockProducts() {
        return productDao.findLowStock();
    }

    // Метод для получения товаров по категории
    public List<Product> findByCategory(Long categoryId) {
        return productDao.findByCategory(categoryId);
    }

    // Метод для проверки существования штрих-кода
    public boolean barcodeExists(String barcode) {
        return productDao.findByBarcode(barcode) != null;
    }
}