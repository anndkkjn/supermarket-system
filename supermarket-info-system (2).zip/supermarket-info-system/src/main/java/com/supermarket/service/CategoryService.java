package com.supermarket.service;

import com.supermarket.dao.CategoryDao;
import com.supermarket.dao.ProductDao;
import com.supermarket.model.Category;
import java.util.List;

public class CategoryService {
    private final CategoryDao categoryDao = new CategoryDao();
    private final ProductDao productDao = new ProductDao(); // Добавляем для подсчета товаров

    public List<Category> getAllCategories() {
        return categoryDao.findAll();
    }

    public List<Category> getActiveCategories() {
        return categoryDao.findActiveCategories();
    }

    public void saveCategory(Category category) {
        categoryDao.save(category);
    }

    public void updateCategory(Category category) {
        categoryDao.update(category);
    }

    public void deleteCategory(Long id) {
        categoryDao.deleteById(id);
    }

    public Category createCategory(String name, String description) {
        Category category = new Category(name, description);
        categoryDao.save(category);
        return category;
    }

    // ВАЖНО: Добавляем недостающий метод!
    public long countProductsInCategory(Long categoryId) {
        // Способ 1: Используем ProductDao для подсчета
        if (categoryId == null) {
            return 0;
        }

        try {
            List<com.supermarket.model.Product> products = productDao.findByCategory(categoryId);
            return products != null ? products.size() : 0;
        } catch (Exception e) {
            // В случае ошибки возвращаем 0
            return 0;
        }

        // Способ 2: Если у Category есть связь с Product, можно использовать:
        // Category category = categoryDao.findById(categoryId);
        // return category != null && category.getProducts() != null ?
        //        category.getProducts().size() : 0;
    }

    // Дополнительные полезные методы:
    public Category getCategoryById(Long id) {
        return categoryDao.findById(id);
    }

    public Category findCategoryByName(String name) {
        return categoryDao.findByName(name);
    }

    public boolean categoryHasProducts(Long categoryId) {
        return countProductsInCategory(categoryId) > 0;
    }
}