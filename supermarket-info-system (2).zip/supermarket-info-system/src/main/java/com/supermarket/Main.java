package com.supermarket;

import com.supermarket.controller.LoginController;
import com.supermarket.util.HibernateUtil;
import com.supermarket.util.TestDataInitializer;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("=== ЗАПУСК ПРИЛОЖЕНИЯ ===");

        try {
            // 1. Инициализация Hibernate
            System.out.println("Инициализация Hibernate...");
            HibernateUtil.getSessionFactory();

            // 2. Инициализация тестовых данных
            System.out.println("Инициализация тестовых данных...");
            TestDataInitializer.initialize();

            // 3. Загружаем окно входа
            System.out.println("Загрузка окна входа...");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();

            // 4. Получаем контроллер (если нужно настроить)
            LoginController loginController = loader.getController();

            // 5. Создаем сцену
            Scene scene = new Scene(root, 600, 400);

            // 6. Настраиваем Stage
            primaryStage.setTitle("Вход в систему - Продуктовый магазин");
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);

            // 7. Добавляем иконку
            try {
                Image icon = new Image(Objects.requireNonNull(
                        getClass().getResourceAsStream("/images/store-icon.png")));
                primaryStage.getIcons().add(icon);
            } catch (Exception e) {
                System.err.println("Не удалось загрузить иконку: " + e.getMessage());
            }

            // 8. Показываем окно
            primaryStage.show();

            System.out.println("Окно входа успешно отображено");

        } catch (Exception e) {
            System.err.println("Ошибка при запуске приложения:");
            e.printStackTrace();

            // Показываем сообщение об ошибке
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                    javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Ошибка запуска");
            alert.setHeaderText("Не удалось запустить приложение");
            alert.setContentText("Ошибка: " + e.getMessage());
            alert.showAndWait();
        }
    }

    @Override
    public void stop() throws Exception {
        System.out.println("=== ЗАВЕРШЕНИЕ ПРИЛОЖЕНИЯ ===");
        // Закрываем Hibernate при выходе
        HibernateUtil.shutdown();
        super.stop();
    }

    public static void main(String[] args) {
        System.out.println("Запуск JavaFX приложения...");
        launch(args);
    }
}