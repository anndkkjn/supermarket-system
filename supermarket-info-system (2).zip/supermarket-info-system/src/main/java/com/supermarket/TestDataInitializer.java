package com.supermarket.util;

import com.supermarket.model.User;
import com.supermarket.model.UserRole;
import com.supermarket.service.UserService;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.mindrot.jbcrypt.BCrypt;

public class TestDataInitializer {

    public static void initialize() {
        System.out.println("=== ИНИЦИАЛИЗАЦИЯ ТЕСТОВЫХ ДАННЫХ ===");

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            // Создаем тестовых пользователей, если их нет
            createTestUsers(session);

            transaction.commit();
            System.out.println("Тестовые данные успешно созданы");

        } catch (Exception e) {
            System.err.println("Ошибка при создании тестовых данных: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void createTestUsers(Session session) {
        System.out.println("Проверка существующих пользователей...");

        // Проверяем и создаем администратора
        User admin = session.createQuery(
                        "FROM User WHERE username = :username", User.class)
                .setParameter("username", "admin")
                .uniqueResult();

        if (admin == null) {
            admin = new User();
            admin.setUsername("admin");
            admin.setPasswordHash(BCrypt.hashpw("admin123", BCrypt.gensalt()));
            admin.setRole(UserRole.ADMIN);
            admin.setFullName("Администратор Системы");
            admin.setEmail("admin@supermarket.com");
            admin.setIsActive(true);

            session.save(admin);
            System.out.println("Создан администратор: admin / admin123");
        } else {
            System.out.println("Администратор уже существует");
        }

        // Проверяем и создаем менеджера
        User manager = session.createQuery(
                        "FROM User WHERE username = :username", User.class)
                .setParameter("username", "manager")
                .uniqueResult();

        if (manager == null) {
            manager = new User();
            manager.setUsername("manager");
            manager.setPasswordHash(BCrypt.hashpw("manager123", BCrypt.gensalt()));
            manager.setRole(UserRole.MANAGER);
            manager.setFullName("Менеджер Магазина");
            manager.setEmail("manager@supermarket.com");
            manager.setIsActive(true);

            session.save(manager);
            System.out.println("Создан менеджер: manager / manager123");
        } else {
            System.out.println("Менеджер уже существует");
        }

        // Проверяем и создаем кассира
        User cashier = session.createQuery(
                        "FROM User WHERE username = :username", User.class)
                .setParameter("username", "cashier")
                .uniqueResult();

        if (cashier == null) {
            cashier = new User();
            cashier.setUsername("cashier");
            cashier.setPasswordHash(BCrypt.hashpw("cashier123", BCrypt.gensalt()));
            cashier.setRole(UserRole.CASHIER);
            cashier.setFullName("Кассир Иванова");
            cashier.setEmail("cashier@supermarket.com");
            cashier.setIsActive(true);

            session.save(cashier);
            System.out.println("Создан кассир: cashier / cashier123");
        } else {
            System.out.println("Кассир уже существует");
        }

        // Создаем несколько тестовых товаров (опционально)
        createTestProducts(session);
    }

    private static void createTestProducts(Session session) {
        System.out.println("Создание тестовых товаров...");
        // Здесь можно добавить создание тестовых товаров и категорий
    }
}