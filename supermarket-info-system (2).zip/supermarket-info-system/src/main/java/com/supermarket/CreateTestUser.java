package com.supermarket;

import com.supermarket.model.User;
import com.supermarket.model.UserRole;
import com.supermarket.service.UserService;
import com.supermarket.util.HibernateUtil;

public class CreateTestUser {
    public static void main(String[] args) {
        System.out.println("=== СОЗДАНИЕ ТЕСТОВОГО ПОЛЬЗОВАТЕЛЯ ===");

        try {
            // Инициализация Hibernate
            HibernateUtil.getSessionFactory();

            UserService userService = new UserService();

            // Проверяем, существует ли уже пользователь admin
            var existingUser = userService.findByUsername("admin");
            if (existingUser.isPresent()) {
                System.out.println("ℹ️ Пользователь 'admin' уже существует");
                System.out.println("ID: " + existingUser.get().getId());
                System.out.println("Роль: " + existingUser.get().getRole());
                return;
            }

            // Создаем администратора
            System.out.println("Создаю пользователя admin...");
            User admin = userService.registerUser(
                    "admin",
                    "admin123",  // пароль
                    UserRole.ADMIN,
                    "Администратор Системы",
                    "admin@supermarket.local"
            );

            System.out.println("✅ Пользователь создан успешно!");
            System.out.println("ID: " + admin.getId());
            System.out.println("Логин: " + admin.getUsername());
            System.out.println("Роль: " + admin.getRole());
            System.out.println("Пароль хэш: " + admin.getPasswordHash().substring(0, 20) + "...");

            // Создаем еще тестовых пользователей
            System.out.println("\nСоздаю дополнительных пользователей...");

            userService.registerUser(
                    "manager",
                    "manager123",
                    UserRole.MANAGER,
                    "Менеджер Магазина",
                    "manager@supermarket.local"
            );
            System.out.println("✅ Менеджер создан");

            userService.registerUser(
                    "cashier",
                    "cashier123",
                    UserRole.CASHIER,
                    "Кассир Иванов Иван",
                    "cashier@supermarket.local"
            );
            System.out.println("✅ Кассир создан");

            // Проверяем аутентификацию
            System.out.println("\n=== ТЕСТ АУТЕНТИФИКАЦИИ ===");

            var authResult = userService.authenticate("admin", "admin123");
            if (authResult.isPresent()) {
                System.out.println("✅ Аутентификация успешна!");
                System.out.println("Пользователь: " + authResult.get().getFullName());
            } else {
                System.out.println("❌ Аутентификация не удалась");
            }

        } catch (Exception e) {
            System.err.println("❌ ОШИБКА: " + e.getMessage());
            e.printStackTrace();
        } finally {
            HibernateUtil.shutdown();
        }
    }
}