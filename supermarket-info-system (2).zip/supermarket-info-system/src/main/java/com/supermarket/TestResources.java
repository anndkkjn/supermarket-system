package com.supermarket;

import java.net.URL;

public class TestResources {
    public static void main(String[] args) {
        System.out.println("=== ТЕСТ РЕСУРСОВ ===");

        // Проверяем пути к ресурсам
        checkResource("/fxml/login.fxml");
        checkResource("/fxml/main.fxml");
        checkResource("/META-INF/persistence.xml");
    }

    private static void checkResource(String path) {
        URL url = TestResources.class.getResource(path);
        if (url != null) {
            System.out.println("✅ Найден: " + path + " -> " + url);
        } else {
            System.out.println("❌ НЕ НАЙДЕН: " + path);
        }
    }
}