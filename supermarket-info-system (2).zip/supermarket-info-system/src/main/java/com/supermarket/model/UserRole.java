package com.supermarket.model;

public enum UserRole {
    ADMIN("Администратор"),
    MANAGER("Менеджер"),
    CASHIER("Кассир"),
    STOREKEEPER("Кладовщик");

    private final String displayName;

    UserRole(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}