package com.supermarket.util;

import com.supermarket.model.User;
import com.supermarket.model.UserRole;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;

    private SessionManager() {
        // Приватный конструктор для Singleton
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public boolean isAdmin() {
        return currentUser != null && currentUser.getRole() == UserRole.ADMIN;
    }

    public boolean isManager() {
        return currentUser != null && currentUser.getRole() == UserRole.MANAGER;
    }

    public boolean isCashier() {
        return currentUser != null && currentUser.getRole() == UserRole.CASHIER;
    }

    public boolean isAuthenticated() {
        return currentUser != null;
    }

    public void logout() {
        this.currentUser = null;
    }

    public boolean isCurrentUser(User user) {
        if (currentUser == null || user == null) return false;
        return currentUser.getId().equals(user.getId());
    }

    public String getUserRoleName() {
        if (currentUser == null) return "Не авторизован";
        return currentUser.getRole().getDisplayName();
    }

    public String getUserFullName() {
        if (currentUser == null) return "Гость";
        return currentUser.getFullName() != null ? currentUser.getFullName() : currentUser.getUsername();
    }

    // ДОБАВЛЯЕМ ЭТОТ МЕТОД
    public boolean hasPermission(String permission) {
        if (currentUser == null) return false;

        switch (currentUser.getRole()) {
            case ADMIN:
                return true; // Админ имеет все права
            case MANAGER:
                return permission.equals("manage_products") ||
                        permission.equals("manage_categories") ||
                        permission.equals("view_reports") ||
                        permission.equals("manage_sales");
            case CASHIER:
                return permission.equals("view_products") ||
                        permission.equals("manage_sales");
            default:
                return false;
        }
    }
}