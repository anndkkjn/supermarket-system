// src/main/java/com/supermarket/util/IconHelper.java
package com.supermarket.util;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;

public class IconHelper {

    // Шрифт загружен?
    private static boolean fontLoaded = false;

    public static void loadIcons() {
        try {
            // Загружаем шрифт програмmatically
            java.io.File fontFile = new java.io.File(
                    IconHelper.class.getResource("/fonts/FontAwesome.ttf").toURI()
            );
            javafx.scene.text.Font.loadFont(fontFile.toURI().toString(), 12);
            fontLoaded = true;
            System.out.println("FontAwesome загружен успешно");
        } catch (Exception e) {
            System.err.println("Не удалось загрузить FontAwesome: " + e.getMessage());
        }
    }

    public static Button createIconButton(String iconClass, String text) {
        Button button = new Button();
        button.getStyleClass().addAll("icon", iconClass);
        button.setText(" " + text);
        return button;
    }

    public static Label createIconLabel(String iconClass, String text) {
        Label label = new Label();
        label.getStyleClass().addAll("icon", iconClass);
        label.setText(" " + text);
        return label;
    }

    // Предопределенные иконки
    public static Button createAddButton() {
        return createIconButton("icon-add", "Добавить");
    }

    public static Button createSearchButton() {
        return createIconButton("icon-search", "Поиск");
    }

    public static Button createEditButton() {
        return createIconButton("icon-edit", "Изменить");
    }

    public static Button createDeleteButton() {
        return createIconButton("icon-delete", "Удалить");
    }
}