package com.supermarket.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;

import java.util.HashMap;
import java.util.Map;

public class HibernateUtil {
    private static SessionFactory sessionFactory;
    private static boolean usingPostgreSQL = true;

    static {
        try {
            System.out.println("=== ИНИЦИАЛИЗАЦИЯ БАЗЫ ДАННЫХ ===");
            System.out.println("Используем PostgreSQL 17");
            System.out.println("База данных: supermarket_db");
            System.out.println("Пользователь: postgres (без пароля)");

            StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                    .applySettings(getSettings())
                    .build();

            Metadata metadata = new MetadataSources(standardRegistry)
                    .addAnnotatedClass(com.supermarket.model.User.class)
                    .addAnnotatedClass(com.supermarket.model.Product.class)
                    .addAnnotatedClass(com.supermarket.model.Category.class)
                    .getMetadataBuilder()
                    .build();

            sessionFactory = metadata.getSessionFactoryBuilder().build();

            System.out.println("✅ Hibernate инициализирован для PostgreSQL");
            System.out.println("=================================");

        } catch (Exception e) {
            System.err.println("❌ Ошибка создания SessionFactory: " + e.getMessage());
            e.printStackTrace();
            throw new ExceptionInInitializerError(e);
        }
    }

    private static Map<String, String> getSettings() {
        Map<String, String> settings = new HashMap<>();

        // PostgreSQL настройки (версия 17)
        settings.put(Environment.DRIVER, "org.postgresql.Driver");
        settings.put(Environment.URL, "jdbc:postgresql://localhost:5432/supermarket_db");
        settings.put(Environment.USER, "postgres");
        settings.put(Environment.PASS, ""); // Пустой пароль
        settings.put(Environment.DIALECT, "org.hibernate.dialect.PostgreSQLDialect");

        // Общие настройки Hibernate
        settings.put(Environment.HBM2DDL_AUTO, "update");
        settings.put(Environment.SHOW_SQL, "true");
        settings.put(Environment.FORMAT_SQL, "true");
        settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");

        // Кодировка для русских символов (добавляется в URL)
        String urlWithEncoding = "jdbc:postgresql://localhost:5432/supermarket_db" +
                "?useUnicode=true&characterEncoding=UTF-8";
        settings.put(Environment.URL, urlWithEncoding);

        // Оптимизации для PostgreSQL
        settings.put("hibernate.jdbc.batch_size", "20");
        settings.put("hibernate.order_inserts", "true");
        settings.put("hibernate.order_updates", "true");

        // Connection pool для Hibernate
        settings.put(Environment.C3P0_MIN_SIZE, "5");
        settings.put(Environment.C3P0_MAX_SIZE, "20");
        settings.put(Environment.C3P0_TIMEOUT, "300");
        settings.put(Environment.C3P0_MAX_STATEMENTS, "50");
        settings.put(Environment.C3P0_IDLE_TEST_PERIOD, "3000");

        return settings;
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static boolean isUsingPostgreSQL() {
        return usingPostgreSQL;
    }

    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close();
            System.out.println("✅ Hibernate SessionFactory закрыт");
        }
    }
}