package com.supermarket.dao;

import com.supermarket.model.Category;
import com.supermarket.util.HibernateUtil; // Добавляем этот импорт!
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class CategoryDao extends GenericDao<Category> {

    public CategoryDao() {
        super(Category.class);
    }

    public List<Category> findActiveCategories() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Category> query = session.createQuery(
                    "FROM Category WHERE isActive = true ORDER BY name", Category.class);
            return query.list();
        }
    }

    public Category findByName(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Category> query = session.createQuery(
                    "FROM Category WHERE name = :name", Category.class);
            query.setParameter("name", name);
            return query.uniqueResult();
        }
    }

    // Дополнительный метод для поиска по части имени
    public List<Category> searchByName(String searchText) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Category> query = session.createQuery(
                    "FROM Category WHERE LOWER(name) LIKE LOWER(:searchText)", Category.class);
            query.setParameter("searchText", "%" + searchText + "%");
            return query.list();
        }
    }
    public List<Category> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Category> query = session.createQuery(
                    "FROM Category ORDER BY name", Category.class);
            return query.list();
        }
    }
    public List<String> getAllCategoryNames() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<String> query = session.createQuery(
                    "SELECT DISTINCT c.name FROM Category c ORDER BY c.name", String.class);
            return query.list();
        } catch (Exception e) {
            System.err.println("Ошибка при получении категорий: " + e.getMessage());
            return List.of();
        }
    }
}