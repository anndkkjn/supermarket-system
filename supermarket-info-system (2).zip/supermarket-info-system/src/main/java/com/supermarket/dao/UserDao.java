package com.supermarket.dao;

import com.supermarket.model.User;
import com.supermarket.util.HibernateUtil;  // ЭТОТ ИМПОРТ ДОЛЖЕН БЫТЬ!
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Optional;


public class UserDao extends GenericDao<User> {

    public UserDao() {
        super(User.class);
    }

    public Optional<User> findByUsername(String username) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<User> query = session.createQuery(
                    "FROM User WHERE username = :username", User.class);
            query.setParameter("username", username);
            return query.uniqueResultOptional();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске по имени пользователя", e);
        }
    }

    public List<User> findByRole(String role) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<User> query = session.createQuery(
                    "FROM User WHERE role = :role", User.class);
            query.setParameter("role", role);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске по роли", e);
        }
    }

    public boolean usernameExists(String username) {
        return findByUsername(username).isPresent();
    }
}