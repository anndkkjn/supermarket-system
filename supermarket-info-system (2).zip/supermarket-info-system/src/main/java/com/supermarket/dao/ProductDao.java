package com.supermarket.dao;

import com.supermarket.model.Product;
import com.supermarket.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;
import java.math.BigDecimal; // ДОБАВЬТЕ ЭТОТ ИМПОРТ!
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

public class ProductDao extends GenericDao<Product> {

    public ProductDao() {
        super(Product.class);
    }

    // ================== ПЕРЕОПРЕДЕЛЕННЫЙ findAll() С JOIN FETCH ==================
    @Override
    public List<Product> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "ORDER BY p.name", Product.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при получении всех товаров", e);
        }
    }

    // ================== НОВЫЙ МЕТОД ДЛЯ СТАТИСТИКИ: findByCategory ==================
    public List<Product> findByCategory(Long categoryId) {
        System.out.println("=== DEBUG: ProductDao.findByCategory(" + categoryId + ") ===");
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE p.category.id = :categoryId " +
                            "ORDER BY p.name", Product.class);
            query.setParameter("categoryId", categoryId);
            List<Product> result = query.list();
            System.out.println("Найдено товаров в категории: " + result.size());
            return result;
        } catch (Exception e) {
            System.err.println("Ошибка при поиске товаров по категории: " + e.getMessage());
            return List.of(); // Возвращаем пустой список вместо исключения
        }
    }

    // ================== СПЕЦИАЛЬНЫЕ МЕТОДЫ ДЛЯ СТАТИСТИКИ ==================
    public List<Product> findAllWithCategory() {
        return findAll();
    }

    public List<Product> findAllWithDebug() {
        System.out.println("=== DEBUG: ProductDao.findAllWithDebug() ===");
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "ORDER BY p.name", Product.class);
            List<Product> products = query.list();
            System.out.println("Найдено товаров: " + products.size());
            for (Product p : products) {
                System.out.println("  - " + p.getName() +
                        ", Категория: " + (p.getCategory() != null ? p.getCategory().getName() : "null") +
                        ", Активен: " + p.isActive());
            }
            return products;
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при получении всех товаров", e);
        }
    }

    // ================== ОСНОВНЫЕ МЕТОДЫ ПОИСКА ==================
    public List<Product> searchByName(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE LOWER(p.name) LIKE LOWER(:name) " +
                            "ORDER BY p.name", Product.class);
            query.setParameter("name", "%" + name + "%");
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске товаров по имени", e);
        }
    }

    public List<Product> findByName(String name) {
        return searchByName(name);
    }

    public List<Product> findLowStock() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE p.quantity <= p.minStockLevel AND p.quantity > 0 " +
                            "ORDER BY p.name", Product.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске товаров с низким запасом", e);
        }
    }

    public Product findByBarcode(String barcode) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE p.barcode = :barcode", Product.class);
            query.setParameter("barcode", barcode);
            return query.uniqueResult();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске товара по штрих-коду", e);
        }
    }

    public List<Product> findOutOfStock() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE p.quantity = 0 " +
                            "ORDER BY p.name", Product.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске товаров, которых нет в наличии", e);
        }
    }

    public List<Product> findByManufacturer(String manufacturer) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE LOWER(p.manufacturer) LIKE LOWER(:manufacturer) " +
                            "ORDER BY p.name", Product.class);
            query.setParameter("manufacturer", "%" + manufacturer + "%");
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске товаров по производителю", e);
        }
    }

    // ================== СТАТИСТИЧЕСКИЕ МЕТОДЫ ==================
    public Long countAllProducts() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Long> query = session.createQuery(
                    "SELECT COUNT(*) FROM Product", Long.class);
            return query.uniqueResult();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при подсчете товаров", e);
        }
    }

    public Long countProductsInCategory(Long categoryId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Long> query = session.createQuery(
                    "SELECT COUNT(*) FROM Product WHERE category.id = :categoryId", Long.class);
            query.setParameter("categoryId", categoryId);
            return query.uniqueResult();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при подсчете товаров в категории", e);
        }
    }

    public Double getTotalInventoryValue() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Double> query = session.createQuery(
                    "SELECT SUM(price * quantity) FROM Product", Double.class);
            Double result = query.uniqueResult();
            return result != null ? result : 0.0;
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при расчете стоимости запасов", e);
        }
    }

    // ================== СПЕЦИАЛЬНЫЕ МЕТОДЫ ==================
    public List<Product> findNewestProducts(int limit) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "ORDER BY p.createdAt DESC", Product.class);
            query.setMaxResults(limit);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске новых товаров", e);
        }
    }

    public boolean barcodeExists(String barcode) {
        return findByBarcode(barcode) != null;
    }

    public boolean productNameExists(String name) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Long> query = session.createQuery(
                    "SELECT COUNT(*) FROM Product WHERE LOWER(name) = LOWER(:name)", Long.class);
            query.setParameter("name", name);
            Long count = query.uniqueResult();
            return count != null && count > 0;
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при проверке существования товара", e);
        }
    }

    // ================== МЕТОДЫ ДЛЯ СТАТИСТИКИ АКТИВНОСТИ ==================
    public Map<String, Long> getActivityStats() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT p.isActive, COUNT(p) FROM Product p " +
                            "GROUP BY p.isActive", Object[].class);

            Map<String, Long> stats = new HashMap<>();
            stats.put("Активные", 0L);
            stats.put("Неактивные", 0L);

            List<Object[]> results = query.list();
            for (Object[] result : results) {
                Boolean isActive = (Boolean) result[0];
                Long count = (Long) result[1];

                if (Boolean.TRUE.equals(isActive)) {
                    stats.put("Активные", count);
                } else {
                    stats.put("Неактивные", count);
                }
            }

            return stats;
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при получении статистики активности", e);
        }
    }

    public List<Product> findAllActive() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Product> query = session.createQuery(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE p.isActive = true " +
                            "ORDER BY p.name", Product.class);
            return query.list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при получении активных товаров", e);
        }
    }

    // ================== НОВЫЙ МЕТОД ДЛЯ СТАТИСТИКИ КАТЕГОРИЙ ==================
    // В ProductDao.java обновите метод getTotalValueByCategory:
    public Map<String, Double> getTotalValueByCategory() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<Object[]> query = session.createQuery(
                    "SELECT c.name, SUM(p.price * p.quantity) " +
                            "FROM Product p JOIN p.category c " +
                            "GROUP BY c.name", Object[].class);

            Map<String, Double> result = new HashMap<>();
            List<Object[]> results = query.list();

            for (Object[] row : results) {
                String categoryName = (String) row[0];
                BigDecimal totalValue = (BigDecimal) row[1]; // Изменено на BigDecimal
                if (totalValue != null) {
                    result.put(categoryName, totalValue.doubleValue());
                }
            }

            return result;
        } catch (Exception e) {
            System.err.println("Ошибка при получении стоимости по категориям: " + e.getMessage());
            return new HashMap<>();
        }
    }// ================== РАСШИРЕННЫЙ ПОИСК ==================

    // В ProductDao.java добавьте:
    public void debugAllProducts() {
        System.out.println("=== DEBUG ALL PRODUCTS IN DATABASE ===");
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Получаем ВСЕ товары с категориями
            Query<Product> query = session.createQuery(
                    "FROM Product p LEFT JOIN FETCH p.category ORDER BY p.id", Product.class);
            List<Product> allProducts = query.list();

            System.out.println("Total products in DB: " + allProducts.size());

            if (allProducts.isEmpty()) {
                System.out.println("DATABASE IS EMPTY! No products found.");
                return;
            }

            for (Product p : allProducts) {
                System.out.println("ID: " + p.getId() +
                        " | Name: '" + p.getName() + "'" +
                        " | Category: " + (p.getCategory() != null ?
                        "'" + p.getCategory().getName() + "' (ID: " + p.getCategory().getId() + ")" : "NULL") +
                        " | Price: " + p.getPrice() +
                        " | Quantity: " + p.getQuantity() +
                        " | Active: " + p.isActive() +
                        " | Barcode: " + p.getBarcode());
            }

            // Проверим структуру таблицы
            System.out.println("\n=== CHECKING DATABASE STRUCTURE ===");
            Query<Object[]> tableInfo = session.createNativeQuery(
                    "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS " +
                            "WHERE TABLE_NAME = 'products'", Object[].class);
            List<Object[]> columns = tableInfo.list();
            System.out.println("Products table columns:");
            for (Object[] col : columns) {
                System.out.println("  " + col[0] + " : " + col[1]);
            }

        } catch (Exception e) {
            System.err.println("Error in debugAllProducts: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("=====================================");
    }

    public List<Product> searchProductsAdvanced(String name, String category,
                                                Double minPrice, Double maxPrice,
                                                Integer minQuantity) {
        System.out.println("=== DEBUG: searchProductsAdvanced ===");
        System.out.println("Параметры поиска:");
        System.out.println("  name: '" + name + "'");
        System.out.println("  category: '" + category + "'");
        System.out.println("  minPrice: " + minPrice);
        System.out.println("  maxPrice: " + maxPrice);
        System.out.println("  minQuantity: " + minQuantity);

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            StringBuilder hql = new StringBuilder(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE 1=1 "
            );

            // Добавляем условия
            if (name != null && !name.trim().isEmpty()) {
                hql.append(" AND LOWER(p.name) LIKE LOWER(:name)");
                System.out.println("Добавлен фильтр по имени: '" + name + "'");
            }

            if (category != null && !category.trim().isEmpty()) {
                hql.append(" AND p.category.name = :category");
                System.out.println("Добавлен фильтр по категории: '" + category + "'");
            }

            // ВАЖНО: Добавляем фильтр по цене
            if (minPrice != null) {
                hql.append(" AND p.price >= :minPrice");
                System.out.println("Добавлен фильтр по минимальной цене: " + minPrice);
            }

            if (maxPrice != null) {
                hql.append(" AND p.price <= :maxPrice");
                System.out.println("Добавлен фильтр по максимальной цене: " + maxPrice);
            }

            if (minQuantity != null) {
                hql.append(" AND p.quantity >= :minQuantity");
                System.out.println("Добавлен фильтр по количеству: от " + minQuantity);
            }

            hql.append(" ORDER BY p.name");

            System.out.println("Итоговый HQL запрос: " + hql.toString());
            Query<Product> query = session.createQuery(hql.toString(), Product.class);

            // Устанавливаем параметры
            if (name != null && !name.trim().isEmpty()) {
                query.setParameter("name", "%" + name.trim() + "%");
            }

            if (category != null && !category.trim().isEmpty()) {
                query.setParameter("category", category.trim());
            }

            // ВАЖНО: Конвертируем Double в BigDecimal для параметров цены
            if (minPrice != null) {
                query.setParameter("minPrice", BigDecimal.valueOf(minPrice)); // Конвертация
                System.out.println("Установлен параметр minPrice как BigDecimal: " + minPrice);
            }

            if (maxPrice != null) {
                query.setParameter("maxPrice", BigDecimal.valueOf(maxPrice)); // Конвертация
                System.out.println("Установлен параметр maxPrice как BigDecimal: " + maxPrice);
            }

            if (minQuantity != null) {
                query.setParameter("minQuantity", minQuantity);
            }

            List<Product> results = query.list();
            System.out.println("=== РЕЗУЛЬТАТ ПОИСКА ===");
            System.out.println("Найдено товаров: " + results.size());

            for (Product p : results) {
                System.out.println("  - " + p.getName() +
                        ", Цена: " + p.getPrice() + " руб." +
                        ", Категория: " + (p.getCategory() != null ? p.getCategory().getName() : "нет") +
                        ", Количество: " + p.getQuantity());
            }

            return results;

        } catch (Exception e) {
            System.err.println("Ошибка при расширенном поиске: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public List<Product> findByPriceRange(Double minPrice, Double maxPrice) {
        System.out.println("=== DEBUG: ProductDao.findByPriceRange() called ===");
        System.out.println("Parameters: minPrice=" + minPrice + ", maxPrice=" + maxPrice);

        // Если оба параметра null - возвращаем все товары
        if (minPrice == null && maxPrice == null) {
            System.out.println("Both parameters are null, returning all products");
            return findAll();
        }

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            StringBuilder hql = new StringBuilder(
                    "SELECT DISTINCT p FROM Product p " +
                            "LEFT JOIN FETCH p.category " +
                            "WHERE 1=1 "
            );

            // Динамически строим запрос в зависимости от параметров
            if (minPrice != null && maxPrice != null) {
                hql.append(" AND p.price BETWEEN :minPrice AND :maxPrice");
                System.out.println("Searching: price BETWEEN " + minPrice + " AND " + maxPrice);
            } else if (minPrice != null) {
                hql.append(" AND p.price >= :minPrice");
                System.out.println("Searching: price >= " + minPrice);
            } else if (maxPrice != null) {
                hql.append(" AND p.price <= :maxPrice");
                System.out.println("Searching: price <= " + maxPrice);
            }

            hql.append(" ORDER BY p.name");

            System.out.println("Generated HQL: " + hql.toString());

            Query<Product> query = session.createQuery(hql.toString(), Product.class);

            // ВАЖНО: Конвертируем Double в BigDecimal
            if (minPrice != null && maxPrice != null) {
                query.setParameter("minPrice", BigDecimal.valueOf(minPrice));
                query.setParameter("maxPrice", BigDecimal.valueOf(maxPrice));
            } else if (minPrice != null) {
                query.setParameter("minPrice", BigDecimal.valueOf(minPrice));
            } else if (maxPrice != null) {
                query.setParameter("maxPrice", BigDecimal.valueOf(maxPrice));
            }

            List<Product> results = query.list();
            System.out.println("Found " + results.size() + " products");

            // Отладочный вывод
            for (Product p : results) {
                System.out.println("  - " + p.getName() + ": " + p.getPrice() + " руб." +
                        " [Category: " + (p.getCategory() != null ? p.getCategory().getName() : "none") + "]");
            }

            return results;
        } catch (Exception e) {
            System.err.println("Error in findByPriceRange: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}