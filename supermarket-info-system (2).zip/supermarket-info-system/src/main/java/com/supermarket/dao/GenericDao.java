package com.supermarket.dao;

import com.supermarket.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.function.Consumer;

public abstract class GenericDao<T> {
    private final Class<T> clazz;

    public GenericDao(Class<T> clazz) {
        this.clazz = clazz;
    }

    // Найти по ID
    public T findById(Long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(clazz, id);
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при поиске по ID", e);
        }
    }

    // Получить все записи
    public List<T> findAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM " + clazz.getName(), clazz).list();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при получении всех записей", e);
        }
    }

    // Сохранить новую запись
    public void save(T entity) {
        executeInTransaction(session -> session.save(entity));
    }

    // Обновить существующую запись
    public void update(T entity) {
        executeInTransaction(session -> session.update(entity));
    }

    // Сохранить или обновить (если есть ID - обновить, иначе сохранить)
    public void saveOrUpdate(T entity) {
        executeInTransaction(session -> session.saveOrUpdate(entity));
    }

    // Удалить запись
    public void delete(T entity) {
        executeInTransaction(session -> session.delete(entity));
    }

    // Удалить по ID
    public void deleteById(Long id) {
        executeInTransaction(session -> {
            T entity = session.get(clazz, id);
            if (entity != null) {
                session.delete(entity);
            }
        });
    }

    // Получить количество всех записей
    public Long countAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("SELECT COUNT(*) FROM " + clazz.getName(), Long.class)
                    .uniqueResult();
        } catch (Exception e) {
            throw new RuntimeException("Ошибка при подсчете записей", e);
        }
    }

    // Вспомогательный метод для выполнения операций в транзакции
    protected void executeInTransaction(Consumer<Session> action) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            action.accept(session);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw new RuntimeException("Ошибка при выполнении операции", e);
        }
    }
}