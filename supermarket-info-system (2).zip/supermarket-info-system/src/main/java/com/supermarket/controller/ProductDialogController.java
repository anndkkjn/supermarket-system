package com.supermarket.controller;

import com.supermarket.model.Category;
import com.supermarket.model.Product;
import com.supermarket.service.CategoryService;
import com.supermarket.service.ProductService;
import com.supermarket.util.SessionManager;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.util.StringConverter;

import java.math.BigDecimal;
import java.util.Optional;

public class ProductDialogController {

    @FXML private Label titleLabel;
    @FXML private TextField nameField;
    @FXML private ComboBox<Category> categoryComboBox;
    @FXML private TextField priceField;
    @FXML private TextField quantityField;
    @FXML private TextField unitField;
    @FXML private TextField barcodeField;
    @FXML private TextField minStockField;
    @FXML private TextField maxStockField;
    @FXML private TextField manufacturerField;
    @FXML private TextField supplierField;
    @FXML private TextArea descriptionArea;
    @FXML private Label errorLabel;

    @FXML private Button calculateStockButton;
    @FXML private Button generateBarcodeButton;
    @FXML private Button clearCategoryButton;
    @FXML private Button addCategoryButton;

    private Product product;
    private final CategoryService categoryService = new CategoryService();
    private final ProductService productService = new ProductService();
    private boolean isEditMode = false;

    @FXML
    private void initialize() {
        System.out.println("DEBUG: ProductDialogController инициализирован");

        // Загружаем категории в ComboBox
        loadCategories();

        // Настраиваем валидацию числовых полей
        setupNumericValidation();

        // Настраиваем обработку событий для очистки ошибок
        setupErrorHandling();
    }

    public void configureForCurrentUser() {
        SessionManager session = SessionManager.getInstance();

        if (!session.isAuthenticated()) {
            disableAllFields();
            return;
        }

        // В зависимости от роли настраиваем доступность полей
        if (session.isCashier()) {
            // Кассир может только просматривать
            configureForCashier();
        } else if (session.isManager()) {
            // Менеджер может редактировать, но с ограничениями
            configureForManager();
        } else if (session.isAdmin()) {
            // Админ имеет полный доступ
            configureForAdmin();
        } else {
            // Для других ролей - минимальный доступ
            disableAllFields();
        }
    }

    private void configureForCashier() {
        // Кассир только просматривает
        disableAllFields();
        titleLabel.setText(titleLabel.getText() + " (режим просмотра)");

        // Прячем кнопки действий
        calculateStockButton.setVisible(false);
        generateBarcodeButton.setVisible(false);
        clearCategoryButton.setVisible(false);
        addCategoryButton.setVisible(false);
    }

    private void configureForManager() {
        // Менеджер может редактировать, но не может менять системные настройки
        enableAllFields();

        // Ограничения для менеджера
        barcodeField.setDisable(false); // Может менять, но с проверкой
        minStockField.setDisable(false);
        maxStockField.setDisable(false);

        // Менеджер может добавлять категории
        addCategoryButton.setDisable(false);
    }

    private void configureForAdmin() {
        // Админ имеет полный доступ ко всем полям
        enableAllFields();

        // Все кнопки доступны
        calculateStockButton.setDisable(false);
        generateBarcodeButton.setDisable(false);
        clearCategoryButton.setDisable(false);
        addCategoryButton.setDisable(false);
    }

    private void disableAllFields() {
        nameField.setDisable(true);
        categoryComboBox.setDisable(true);
        priceField.setDisable(true);
        quantityField.setDisable(true);
        unitField.setDisable(true);
        barcodeField.setDisable(true);
        minStockField.setDisable(true);
        maxStockField.setDisable(true);
        manufacturerField.setDisable(true);
        supplierField.setDisable(true);
        descriptionArea.setDisable(true);

        // Кнопки
        calculateStockButton.setDisable(true);
        generateBarcodeButton.setDisable(true);
        clearCategoryButton.setDisable(true);
        addCategoryButton.setDisable(true);
    }

    private void enableAllFields() {
        nameField.setDisable(false);
        categoryComboBox.setDisable(false);
        priceField.setDisable(false);
        quantityField.setDisable(false);
        unitField.setDisable(false);
        barcodeField.setDisable(false);
        minStockField.setDisable(false);
        maxStockField.setDisable(false);
        manufacturerField.setDisable(false);
        supplierField.setDisable(false);
        descriptionArea.setDisable(false);

        // Кнопки
        calculateStockButton.setDisable(false);
        generateBarcodeButton.setDisable(false);
        clearCategoryButton.setDisable(false);
        addCategoryButton.setDisable(false);
    }

    private void loadCategories() {
        try {
            // Загружаем только активные категории
            categoryComboBox.setItems(FXCollections.observableArrayList(
                    categoryService.getActiveCategories()
            ));

            // Настраиваем отображение категорий в ComboBox
            categoryComboBox.setConverter(new StringConverter<Category>() {
                @Override
                public String toString(Category category) {
                    return category != null ? category.getName() : "Без категории";
                }

                @Override
                public Category fromString(String string) {
                    return categoryComboBox.getItems().stream()
                            .filter(c -> c.getName().equals(string))
                            .findFirst()
                            .orElse(null);
                }
            });

            // Добавляем пустую категорию для возможности выбора "Без категории"
            Category noCategory = new Category();
            noCategory.setName("Без категории");
            noCategory.setId(-1L);
            categoryComboBox.getItems().add(0, noCategory);

        } catch (Exception e) {
            showError("Не удалось загрузить категории: " + e.getMessage());
        }
    }

    private void setupNumericValidation() {
        // Валидация для поля цены (только числа с двумя знаками после запятой)
        priceField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*(\\.\\d{0,2})?")) {
                priceField.setText(oldValue);
            }
        });

        // Валидация для полей количества (только целые числа)
        quantityField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                quantityField.setText(oldValue);
            }
        });

        // Валидация для минимального и максимального запаса
        minStockField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                minStockField.setText(oldValue);
            }
        });

        maxStockField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                maxStockField.setText(oldValue);
            }
        });
    }

    private void setupErrorHandling() {
        // Очищаем ошибки при изменении полей
        nameField.textProperty().addListener((obs, oldVal, newVal) -> clearError());
        priceField.textProperty().addListener((obs, oldVal, newVal) -> clearError());
        quantityField.textProperty().addListener((obs, oldVal, newVal) -> clearError());
        barcodeField.textProperty().addListener((obs, oldVal, newVal) -> {
            clearError();
            checkBarcodeUniqueness(newVal);
        });
    }

    private void checkBarcodeUniqueness(String barcode) {
        if (barcode != null && !barcode.trim().isEmpty() && !isEditMode) {
            // Проверяем уникальность штрих-кода только при добавлении нового товара
            // Для существующего товара разрешаем сохранить тот же штрих-код
            boolean exists = productService.getAllProducts().stream()
                    .anyMatch(p -> barcode.equals(p.getBarcode()));

            if (exists) {
                showError("Товар с таким штрих-кодом уже существует");
            }
        }
    }

    public void setProduct(Product product) {
        this.product = product;
        this.isEditMode = product != null && product.getId() != null;

        if (product == null) {
            titleLabel.setText("Добавление нового товара");
            setDefaultValues();
        } else {
            titleLabel.setText("Редактирование товара: " + product.getName());
            fillProductData(product);
        }
    }

    private void setDefaultValues() {
        // Устанавливаем значения по умолчанию для нового товара
        minStockField.setText("10");
        maxStockField.setText("100");
        unitField.setText("шт");
        quantityField.setText("0");

        // Выбираем "Без категории" по умолчанию
        if (categoryComboBox.getItems().size() > 0) {
            categoryComboBox.getSelectionModel().select(0);
        }
    }

    private void fillProductData(Product product) {
        // Заполняем поля данными товара
        nameField.setText(product.getName());
        priceField.setText(product.getPrice().toString());
        quantityField.setText(product.getQuantity().toString());

        // Заполняем опциональные поля, если они не пустые
        if (product.getUnit() != null) {
            unitField.setText(product.getUnit());
        }

        if (product.getBarcode() != null) {
            barcodeField.setText(product.getBarcode());
        }

        if (product.getMinStockLevel() != null) {
            minStockField.setText(product.getMinStockLevel().toString());
        }

        if (product.getMaxStockLevel() != null) {
            maxStockField.setText(product.getMaxStockLevel().toString());
        }

        if (product.getManufacturer() != null) {
            manufacturerField.setText(product.getManufacturer());
        }

        if (product.getSupplier() != null) {
            supplierField.setText(product.getSupplier());
        }

        if (product.getDescription() != null) {
            descriptionArea.setText(product.getDescription());
        }

        // Устанавливаем категорию
        if (product.getCategory() != null) {
            // Ищем категорию в списке
            Optional<Category> matchingCategory = categoryComboBox.getItems().stream()
                    .filter(c -> c.getId() != null && c.getId().equals(product.getCategory().getId()))
                    .findFirst();

            if (matchingCategory.isPresent()) {
                categoryComboBox.setValue(matchingCategory.get());
            }
        } else {
            // Выбираем "Без категории"
            if (categoryComboBox.getItems().size() > 0) {
                categoryComboBox.getSelectionModel().select(0);
            }
        }
    }

    public Product getProduct() {
        if (product == null) {
            product = new Product();
        }

        // Обновляем данные товара
        product.setName(nameField.getText().trim());

        try {
            product.setPrice(new BigDecimal(priceField.getText().trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Некорректная цена");
        }

        try {
            product.setQuantity(Integer.parseInt(quantityField.getText().trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Некорректное количество");
        }

        // Обрабатываем опциональные поля
        String unit = unitField.getText().trim();
        product.setUnit(unit.isEmpty() ? null : unit);

        String barcode = barcodeField.getText().trim();
        product.setBarcode(barcode.isEmpty() ? null : barcode);

        // Обрабатываем минимальный и максимальный запас
        try {
            if (!minStockField.getText().trim().isEmpty()) {
                product.setMinStockLevel(Integer.parseInt(minStockField.getText().trim()));
            } else {
                product.setMinStockLevel(null);
            }

            if (!maxStockField.getText().trim().isEmpty()) {
                product.setMaxStockLevel(Integer.parseInt(maxStockField.getText().trim()));
            } else {
                product.setMaxStockLevel(null);
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Некорректное значение запаса");
        }

        // Проверяем логику минимального и максимального запаса
        if (product.getMinStockLevel() != null && product.getMaxStockLevel() != null) {
            if (product.getMinStockLevel() >= product.getMaxStockLevel()) {
                throw new IllegalArgumentException("Минимальный запас должен быть меньше максимального");
            }
        }

        String manufacturer = manufacturerField.getText().trim();
        product.setManufacturer(manufacturer.isEmpty() ? null : manufacturer);

        String supplier = supplierField.getText().trim();
        product.setSupplier(supplier.isEmpty() ? null : supplier);

        String description = descriptionArea.getText().trim();
        product.setDescription(description.isEmpty() ? null : description);

        // Устанавливаем категорию (если выбрана не "Без категории")
        Category selectedCategory = categoryComboBox.getValue();
        if (selectedCategory != null && selectedCategory.getId() != null && selectedCategory.getId() != -1L) {
            product.setCategory(selectedCategory);
        } else {
            product.setCategory(null);
        }

        return product;
    }

    public boolean validateInput() {
        errorLabel.setText("");

        // Проверяем, есть ли у пользователя права на редактирование
        SessionManager session = SessionManager.getInstance();
        if (isEditMode && !session.hasPermission("manage_products")) {
            showError("У вас нет прав для редактирования товаров");
            return false;
        }

        if (!isEditMode && !session.hasPermission("manage_products")) {
            showError("У вас нет прав для добавления новых товаров");
            return false;
        }

        // Проверка обязательных полей
        if (nameField.getText().trim().isEmpty()) {
            showError("Введите название товара");
            nameField.requestFocus();
            return false;
        }

        if (priceField.getText().trim().isEmpty()) {
            showError("Введите цену товара");
            priceField.requestFocus();
            return false;
        }

        if (quantityField.getText().trim().isEmpty()) {
            showError("Введите количество товара");
            quantityField.requestFocus();
            return false;
        }

        // Проверка числовых полей
        try {
            BigDecimal price = new BigDecimal(priceField.getText().trim());
            if (price.compareTo(BigDecimal.ZERO) <= 0) {
                showError("Цена должна быть больше 0");
                priceField.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Некорректная цена. Используйте формат: 99.99");
            priceField.requestFocus();
            return false;
        }

        try {
            int quantity = Integer.parseInt(quantityField.getText().trim());
            if (quantity < 0) {
                showError("Количество не может быть отрицательным");
                quantityField.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Некорректное количество. Введите целое число");
            quantityField.requestFocus();
            return false;
        }

        // Проверка минимального и максимального запаса
        try {
            if (!minStockField.getText().trim().isEmpty()) {
                int minStock = Integer.parseInt(minStockField.getText().trim());
                if (minStock < 0) {
                    showError("Минимальный запас не может быть отрицательным");
                    minStockField.requestFocus();
                    return false;
                }
            }

            if (!maxStockField.getText().trim().isEmpty()) {
                int maxStock = Integer.parseInt(maxStockField.getText().trim());
                if (maxStock < 0) {
                    showError("Максимальный запас не может быть отрицательным");
                    maxStockField.requestFocus();
                    return false;
                }
            }

            // Проверка логики минимального и максимального запаса
            if (!minStockField.getText().trim().isEmpty() && !maxStockField.getText().trim().isEmpty()) {
                int minStock = Integer.parseInt(minStockField.getText().trim());
                int maxStock = Integer.parseInt(maxStockField.getText().trim());
                if (minStock >= maxStock) {
                    showError("Минимальный запас должен быть меньше максимального");
                    minStockField.requestFocus();
                    return false;
                }
            }
        } catch (NumberFormatException e) {
            showError("Некорректное значение запаса. Введите целое число");
            minStockField.requestFocus();
            return false;
        }

        // Проверка уникальности штрих-кода (только для нового товара)
        String barcode = barcodeField.getText().trim();
        if (!barcode.isEmpty() && !isEditMode) {
            boolean barcodeExists = productService.getAllProducts().stream()
                    .anyMatch(p -> barcode.equals(p.getBarcode()));

            if (barcodeExists) {
                showError("Товар с таким штрих-кодом уже существует");
                barcodeField.requestFocus();
                return false;
            }
        }

        // Проверка длины полей
        if (nameField.getText().trim().length() > 200) {
            showError("Название товара слишком длинное (максимум 200 символов)");
            nameField.requestFocus();
            return false;
        }

        if (manufacturerField.getText().trim().length() > 100) {
            showError("Название производителя слишком длинное (максимум 100 символов)");
            manufacturerField.requestFocus();
            return false;
        }

        if (descriptionArea.getText().trim().length() > 1000) {
            showError("Описание слишком длинное (максимум 1000 символов)");
            descriptionArea.requestFocus();
            return false;
        }

        return true;
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
    }

    private void clearError() {
        errorLabel.setText("");
        errorLabel.setStyle("");
    }

    // Дополнительные методы для управления полями

    @FXML
    private void handleCalculateOptimalStock() {
        // Проверяем права
        if (!SessionManager.getInstance().hasPermission("manage_products")) {
            showError("У вас нет прав для использования этой функции");
            return;
        }

        try {
            if (!quantityField.getText().trim().isEmpty()) {
                int currentQuantity = Integer.parseInt(quantityField.getText().trim());
                // Простая логика расчета оптимального запаса
                int optimalMin = Math.max(10, currentQuantity / 10);
                int optimalMax = optimalMin * 10;

                minStockField.setText(String.valueOf(optimalMin));
                maxStockField.setText(String.valueOf(optimalMax));

                showInfo("Оптимальный запас рассчитан: мин=" + optimalMin + ", макс=" + optimalMax);
            }
        } catch (NumberFormatException e) {
            showError("Сначала укажите текущее количество");
        }
    }

    @FXML
    private void handleGenerateBarcode() {
        // Проверяем права
        if (!SessionManager.getInstance().hasPermission("manage_products")) {
            showError("У вас нет прав для использования этой функции");
            return;
        }

        // Генерация тестового штрих-кода
        String generatedBarcode = "4" + System.currentTimeMillis() % 10000000;
        barcodeField.setText(generatedBarcode);
        showInfo("Сгенерирован штрих-код: " + generatedBarcode);
    }

    @FXML
    private void handleClearCategory() {
        // Проверяем права
        if (!SessionManager.getInstance().hasPermission("manage_products")) {
            showError("У вас нет прав для использования этой функции");
            return;
        }

        if (categoryComboBox.getItems().size() > 0) {
            categoryComboBox.getSelectionModel().select(0); // "Без категории"
            showInfo("Категория очищена");
        }
    }

    @FXML
    private void handleAddCategory() {
        // Проверяем права
        SessionManager session = SessionManager.getInstance();
        if (!session.isAdmin() && !session.isManager()) {
            showError("Только администратор или менеджер может добавлять категории");
            return;
        }

        // Диалог для добавления новой категории
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Новая категория");
        dialog.setHeaderText("Добавление новой категории");
        dialog.setContentText("Введите название категории:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(categoryName -> {
            if (!categoryName.trim().isEmpty()) {
                try {
                    // Проверяем, не существует ли уже такая категория
                    boolean exists = categoryService.getAllCategories().stream()
                            .anyMatch(c -> c.getName().equalsIgnoreCase(categoryName.trim()));

                    if (exists) {
                        showError("Категория с таким названием уже существует");
                        return;
                    }

                    // Создаем новую категорию
                    Category newCategory = categoryService.createCategory(
                            categoryName.trim(),
                            "Добавлена через диалог товара"
                    );

                    // Добавляем в ComboBox и выбираем
                    categoryComboBox.getItems().add(newCategory);
                    categoryComboBox.setValue(newCategory);

                    showInfo("Категория добавлена: " + categoryName);

                } catch (Exception e) {
                    showError("Не удалось добавить категорию: " + e.getMessage());
                }
            }
        });
    }

    private void showInfo(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
    }

    // Геттер для определения режима (редактирование/добавление)
    public boolean isEditMode() {
        return isEditMode;
    }

    // Метод для установки фокуса на первое поле
    public void requestFocusOnFirstField() {
        nameField.requestFocus();
    }

    // Метод для проверки, может ли пользователь сохранить изменения
    public boolean canUserSave() {
        SessionManager session = SessionManager.getInstance();

        if (!session.isAuthenticated()) {
            return false;
        }

        if (isEditMode) {
            return session.hasPermission("manage_products");
        } else {
            return session.hasPermission("manage_products");
        }
    }
}