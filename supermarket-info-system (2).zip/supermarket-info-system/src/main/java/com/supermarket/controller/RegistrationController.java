package com.supermarket.controller;

import com.supermarket.model.UserRole;
import com.supermarket.service.UserService;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class RegistrationController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private ComboBox<UserRole> roleComboBox;
    @FXML private Label statusLabel;

    private final UserService userService = new UserService();

    @FXML
    private void initialize() {
        // Настройка ComboBox с ролями
        roleComboBox.setItems(FXCollections.observableArrayList(
                UserRole.MANAGER,
                UserRole.CASHIER,
                UserRole.STOREKEEPER
        ));
        roleComboBox.setValue(UserRole.CASHIER);

        System.out.println("RegistrationController инициализирован");
    }

    @FXML
    private void handleRegister() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        UserRole role = roleComboBox.getValue();

        System.out.println("Попытка регистрации: " + username);

        // Валидация
        if (!validateInput(username, password, confirmPassword, fullName, email)) {
            return;
        }

        try {
            // Регистрируем пользователя через UserService
            var newUser = userService.registerUser(username, password, role, fullName, email);

            if (newUser != null) {
                showSuccess("✅ Пользователь " + username + " успешно зарегистрирован!");
                System.out.println("✅ Пользователь зарегистрирован: " + username);

                // Закрываем окно через 2 секунды
                closeAfterDelay();
            }

        } catch (Exception e) {
            showError("❌ Ошибка регистрации: " + e.getMessage());
            System.err.println("Ошибка регистрации: " + e.getMessage());
        }
    }

    private boolean validateInput(String username, String password,
                                  String confirmPassword, String fullName,
                                  String email) {

        if (username.isEmpty() || username.length() < 3) {
            showError("Логин должен содержать минимум 3 символа");
            return false;
        }

        if (password.isEmpty() || password.length() < 6) {
            showError("Пароль должен содержать минимум 6 символов");
            return false;
        }

        if (!password.equals(confirmPassword)) {
            showError("Пароли не совпадают");
            return false;
        }

        if (fullName.isEmpty() || fullName.length() < 2) {
            showError("Введите ваше ФИО");
            return false;
        }

        return true;
    }

    private void closeAfterDelay() {
        new Thread(() -> {
            try {
                Thread.sleep(2000);
                javafx.application.Platform.runLater(() -> {
                    Stage stage = (Stage) usernameField.getScene().getWindow();
                    stage.close();
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green;");
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red;");
    }

    @FXML
    private void handleCancel() {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }
}