package com.supermarket.controller;

import com.supermarket.util.SessionManager;
import com.supermarket.model.User;
import com.supermarket.model.UserRole;
import com.supermarket.service.UserService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;  // Добавляем этот импорт!
import javafx.stage.Modality;
import javafx.util.StringConverter;

import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Optional;

public class UsersController {

    // ================== FXML ЭЛЕМЕНТЫ ==================
    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, Long> idColumn;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> fullNameColumn;
    @FXML private TableColumn<User, String> emailColumn;
    @FXML private TableColumn<User, UserRole> roleColumn;
    @FXML private TableColumn<User, String> createdAtColumn;
    @FXML private TableColumn<User, String> statusColumn;

    @FXML private TextField searchField;
    @FXML private ComboBox<UserRole> roleFilterComboBox;
    @FXML private CheckBox activeOnlyCheckBox;
    @FXML private Label statsLabel;

    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;
    @FXML private Button toggleActiveButton;
    @FXML private Button resetPasswordButton;

    // ================== СЕРВИСЫ И ДАННЫЕ ==================
    private final UserService userService = new UserService();
    private final ObservableList<User> userList = FXCollections.observableArrayList();
    private final FilteredList<User> filteredUsers = new FilteredList<>(userList);

    // Пароль по умолчанию для сброса
    private static final String DEFAULT_PASSWORD = "123456";

    // ================== ИНИЦИАЛИЗАЦИЯ ==================
    @FXML
    private void initialize() {
        setupTableColumns();
        setupFilters();
        loadData();
        setupTableSelection();
        updateStatistics();
    }

    // ================== НАСТРОЙКА ТАБЛИЦЫ ==================
    private void setupTableColumns() {
        // ID
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        // Логин
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));

        // ФИО
        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        fullNameColumn.setCellFactory(column -> new TableCell<User, String>() {
            @Override
            protected void updateItem(String fullName, boolean empty) {
                super.updateItem(fullName, empty);
                if (empty || fullName == null) {
                    setText(null);
                } else {
                    setText(fullName);
                }
            }
        });

        // Email
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        // Роль
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        roleColumn.setCellFactory(column -> new TableCell<User, UserRole>() {
            @Override
            protected void updateItem(UserRole role, boolean empty) {
                super.updateItem(role, empty);
                if (empty || role == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(role.getDisplayName());
                    // Цветовое кодирование ролей
                    switch (role) {
                        case ADMIN:
                            setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                            break;
                        case MANAGER:
                            setStyle("-fx-text-fill: #3498db; -fx-font-weight: bold;");
                            break;
                        case CASHIER:
                            setStyle("-fx-text-fill: #2ecc71; -fx-font-weight: bold;");
                            break;
                        default:
                            setStyle("-fx-text-fill: #7f8c8d;");
                            break;
                    }
                }
            }
        });

        // Дата регистрации
        createdAtColumn.setCellValueFactory(cellData ->
                javafx.beans.binding.Bindings.createStringBinding(() ->
                        cellData.getValue().getCreatedAt().format(
                                DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)
                        )
                )
        );

        // Статус (активен/неактивен)
        statusColumn.setCellValueFactory(cellData ->
                javafx.beans.binding.Bindings.createStringBinding(() ->
                        Boolean.TRUE.equals(cellData.getValue().getIsActive()) ? "Активен" : "Неактивен"
                )
        );
        statusColumn.setCellFactory(column -> new TableCell<User, String>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status);
                    if (status.equals("Активен")) {
                        setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                    }
                }
            }
        });

        // Контекстное меню для таблицы
        setupContextMenu();
    }

    private void setupContextMenu() {
        ContextMenu contextMenu = new ContextMenu();

        MenuItem editItem = new MenuItem("Редактировать");
        editItem.setOnAction(event -> handleEditUser());

        MenuItem toggleActiveItem = new MenuItem("Активировать/Деактивировать");
        toggleActiveItem.setOnAction(event -> handleToggleActive());

        MenuItem resetPasswordItem = new MenuItem("Сбросить пароль");
        resetPasswordItem.setOnAction(event -> handleResetPassword());

        MenuItem deleteItem = new MenuItem("Удалить");
        deleteItem.setOnAction(event -> handleDeleteUser());

        contextMenu.getItems().addAll(
                editItem,
                new SeparatorMenuItem(),
                toggleActiveItem,
                resetPasswordItem,
                new SeparatorMenuItem(),
                deleteItem
        );

        usersTable.setContextMenu(contextMenu);

        // Двойной клик для редактирования
        usersTable.setRowFactory(tv -> {
            TableRow<User> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    handleEditUser();
                }
            });
            return row;
        });
    }

    // ================== НАСТРОЙКА ФИЛЬТРОВ ==================
    private void setupFilters() {
        // Настройка ComboBox с ролями
        roleFilterComboBox.getItems().addAll(UserRole.values());
        roleFilterComboBox.getItems().add(0, null);
        roleFilterComboBox.setConverter(new StringConverter<UserRole>() {
            @Override
            public String toString(UserRole role) {
                return role == null ? "Все роли" : role.getDisplayName();
            }

            @Override
            public UserRole fromString(String string) {
                return roleFilterComboBox.getItems().stream()
                        .filter(r -> r != null && r.getDisplayName().equals(string))
                        .findFirst()
                        .orElse(null);
            }
        });
        roleFilterComboBox.setValue(null);

        // Настройка фильтрации
        filteredUsers.setPredicate(user -> {
            // Фильтр по поиску
            String searchText = searchField.getText().toLowerCase();
            if (!searchText.isEmpty()) {
                boolean matches = user.getUsername().toLowerCase().contains(searchText) ||
                        (user.getFullName() != null &&
                                user.getFullName().toLowerCase().contains(searchText)) ||
                        (user.getEmail() != null &&
                                user.getEmail().toLowerCase().contains(searchText));
                if (!matches) return false;
            }

            // Фильтр по роли
            UserRole selectedRole = roleFilterComboBox.getValue();
            if (selectedRole != null && user.getRole() != selectedRole) {
                return false;
            }

            // Фильтр по активности
            if (activeOnlyCheckBox.isSelected() && !Boolean.TRUE.equals(user.getIsActive())) {
                return false;
            }

            return true;
        });

        // Настройка обработчиков изменений фильтров
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredUsers.setPredicate(filteredUsers.getPredicate());
            updateStatistics();
        });

        roleFilterComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            filteredUsers.setPredicate(filteredUsers.getPredicate());
            updateStatistics();
        });

        activeOnlyCheckBox.selectedProperty().addListener((observable, oldValue, newValue) -> {
            filteredUsers.setPredicate(filteredUsers.getPredicate());
            updateStatistics();
        });

        // Сортировка
        SortedList<User> sortedUsers = new SortedList<>(filteredUsers);
        sortedUsers.comparatorProperty().bind(usersTable.comparatorProperty());
        usersTable.setItems(sortedUsers);
    }

    // ================== ЗАГРУЗКА ДАННЫХ ==================
    private void loadData() {
        try {
            userList.clear();
            userList.addAll(userService.getAllUsers());

            // Обновляем статистику
            updateStatistics();

        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Ошибка загрузки",
                    "Не удалось загрузить данные пользователей: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ================== ОБНОВЛЕНИЕ СТАТИСТИКИ ==================
    private void updateStatistics() {
        long totalUsers = userList.size();
        long activeUsers = userList.stream()
                .filter(u -> Boolean.TRUE.equals(u.getIsActive()))
                .count();
        long filteredCount = filteredUsers.size();

        // Статистика по ролям
        long adminCount = userList.stream()
                .filter(u -> u.getRole() == UserRole.ADMIN)
                .count();
        long managerCount = userList.stream()
                .filter(u -> u.getRole() == UserRole.MANAGER)
                .count();
        long cashierCount = userList.stream()
                .filter(u -> u.getRole() == UserRole.CASHIER)
                .count();

        statsLabel.setText(String.format(
                "Пользователей: %d (активных: %d, показано: %d)%n" +
                        "Роли: Админ: %d | Менеджер: %d | Кассир: %d",
                totalUsers, activeUsers, filteredCount,
                adminCount, managerCount, cashierCount
        ));
    }

    // ================== НАСТРОЙКА ВЫБОРА В ТАБЛИЦЕ ==================
    private void setupTableSelection() {
        usersTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean isSelected = newValue != null;
                    boolean isAdmin = isSelected && newValue.getRole() == UserRole.ADMIN;
                    boolean isCurrentUser = isSelected && isCurrentUser(newValue);

                    editButton.setDisable(!isSelected);
                    deleteButton.setDisable(!isSelected || isAdmin || isCurrentUser);
                    toggleActiveButton.setDisable(!isSelected || isCurrentUser);
                    resetPasswordButton.setDisable(!isSelected);

                    // Обновляем текст кнопки активации
                    if (isSelected) {
                        toggleActiveButton.setText(
                                Boolean.TRUE.equals(newValue.getIsActive()) ?
                                        "Деактивировать" : "Активировать"
                        );
                    }
                }
        );
    }

    private boolean isCurrentUser(User user) {
        // TODO: Реализовать проверку, является ли пользователь текущим
        // Пока возвращаем false для тестирования
        return false;
    }

    // ================== ОБРАБОТЧИКИ ДЕЙСТВИЙ ==================
    @FXML
    private void handleAddUser() {
        showUserDialog(null);
    }

    @FXML
    private void handleEditUser() {
        User selected = usersTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            showUserDialog(selected);
        }
    }

    @FXML
    private void handleDeleteUser() {
        User selected = usersTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Проверяем, можно ли удалить пользователя
            if (selected.getRole() == UserRole.ADMIN) {
                showAlert(Alert.AlertType.WARNING,
                        "Невозможно удалить",
                        "Нельзя удалить администратора системы.");
                return;
            }

            if (isCurrentUser(selected)) {
                showAlert(Alert.AlertType.WARNING,
                        "Невозможно удалить",
                        "Нельзя удалить текущего пользователя.");
                return;
            }

            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            confirmation.setTitle("Подтверждение удаления");
            confirmation.setHeaderText("Удаление пользователя");
            confirmation.setContentText(String.format(
                    "Вы уверены, что хотите удалить пользователя?%n" +
                            "Логин: %s%n" +
                            "ФИО: %s%n%n" +
                            "Это действие нельзя отменить.",
                    selected.getUsername(),
                    selected.getFullName() != null ? selected.getFullName() : "Не указано"
            ));

            confirmation.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    try {
                        userService.deleteUser(selected.getId());
                        userList.remove(selected);
                        updateStatistics();
                        showAlert(Alert.AlertType.INFORMATION,
                                "Пользователь удален",
                                "Пользователь успешно удален из системы.");
                    } catch (Exception e) {
                        showAlert(Alert.AlertType.ERROR,
                                "Ошибка удаления",
                                "Не удалось удалить пользователя: " + e.getMessage());
                    }
                }
            });
        }
    }

    @FXML
    private void handleToggleActive() {
        User selected = usersTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Проверяем, не пытаемся ли изменить статус текущего пользователя
            if (isCurrentUser(selected)) {
                showAlert(Alert.AlertType.WARNING,
                        "Невозможно изменить",
                        "Нельзя изменить статус текущего пользователя.");
                return;
            }

            String action = Boolean.TRUE.equals(selected.getIsActive()) ?
                    "деактивировать" : "активировать";

            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            confirmation.setTitle("Подтверждение");
            confirmation.setHeaderText("Изменение статуса пользователя");
            confirmation.setContentText(String.format(
                    "Вы уверены, что хотите %s пользователя?%n" +
                            "Логин: %s",
                    action, selected.getUsername()
            ));

            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    try {
                        selected.setIsActive(!Boolean.TRUE.equals(selected.getIsActive()));
                        userService.updateUser(selected);
                        usersTable.refresh();
                        updateStatistics();

                        String newStatus = Boolean.TRUE.equals(selected.getIsActive()) ?
                                "активирован" : "деактивирован";
                        showAlert(Alert.AlertType.INFORMATION,
                                "Статус изменен",
                                "Пользователь " + selected.getUsername() + " " + newStatus);
                    } catch (Exception e) {
                        showAlert(Alert.AlertType.ERROR,
                                "Ошибка",
                                "Не удалось изменить статус: " + e.getMessage());
                    }
                }
            });
        }
    }

    @FXML
    private void handleResetPassword() {
        User selected = usersTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            confirmation.setTitle("Сброс пароля");
            confirmation.setHeaderText("Сброс пароля пользователя");
            confirmation.setContentText(String.format(
                    "Вы уверены, что хотите сбросить пароль пользователю?%n" +
                            "Логин: %s%n%n" +
                            "Новый пароль будет: %s%n" +
                            "Пользователю необходимо будет изменить пароль при следующем входе.",
                    selected.getUsername(), DEFAULT_PASSWORD
            ));

            confirmation.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    try {
                        // Сбрасываем пароль на значение по умолчанию
                        // TODO: Реализовать метод сброса пароля в UserService
                        // userService.resetPassword(selected.getId(), DEFAULT_PASSWORD);

                        showAlert(Alert.AlertType.INFORMATION,
                                "Пароль сброшен",
                                String.format(
                                        "Пароль пользователя %s сброшен.%n" +
                                                "Новый пароль: %s",
                                        selected.getUsername(), DEFAULT_PASSWORD
                                ));
                    } catch (Exception e) {
                        showAlert(Alert.AlertType.ERROR,
                                "Ошибка",
                                "Не удалось сбросить пароль: " + e.getMessage());
                    }
                }
            });
        }
    }

    @FXML
    private void handleRefresh() {
        loadData();
        showAlert(Alert.AlertType.INFORMATION,
                "Данные обновлены",
                "Список пользователей успешно обновлен.");
    }

    @FXML
    private void handleExportUsers() {
        // TODO: Реализовать экспорт пользователей
        showAlert(Alert.AlertType.INFORMATION,
                "Экспорт данных",
                "Функция экспорта будет реализована в следующей версии.");
    }

    // ================== ДИАЛОГОВОЕ ОКНО ДЛЯ ПОЛЬЗОВАТЕЛЯ ==================
    private void showUserDialog(User user) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle(user == null ? "Добавление пользователя" : "Редактирование пользователя");
        dialog.initModality(Modality.APPLICATION_MODAL);

        // Создаем форму
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new javafx.geometry.Insets(20, 150, 10, 10));

        // Поля формы
        TextField usernameField = new TextField();
        usernameField.setPromptText("Логин");
        usernameField.setPrefWidth(200);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Пароль");

        TextField fullNameField = new TextField();
        fullNameField.setPromptText("ФИО");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        ComboBox<UserRole> roleCombo = new ComboBox<>();
        roleCombo.getItems().addAll(UserRole.values());
        roleCombo.setConverter(new StringConverter<UserRole>() {
            @Override
            public String toString(UserRole role) {
                return role.getDisplayName();
            }

            @Override
            public UserRole fromString(String string) {
                return null;
            }
        });

        CheckBox activeCheckBox = new CheckBox("Активен");
        activeCheckBox.setSelected(true);

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        // Заполняем данные если редактируем
        if (user != null) {
            usernameField.setText(user.getUsername());
            usernameField.setDisable(true); // Нельзя менять логин

            fullNameField.setText(user.getFullName());
            emailField.setText(user.getEmail());
            roleCombo.setValue(user.getRole());
            activeCheckBox.setSelected(Boolean.TRUE.equals(user.getIsActive()));

            passwordField.setPromptText("Оставьте пустым, чтобы не менять пароль");
        } else {
            roleCombo.setValue(UserRole.CASHIER);
        }

        // Добавляем элементы в сетку
        grid.add(new Label("Логин*:"), 0, 0);
        grid.add(usernameField, 1, 0);

        grid.add(new Label("Пароль" + (user == null ? "*:" : ":")), 0, 1);
        grid.add(passwordField, 1, 1);

        grid.add(new Label("ФИО*:"), 0, 2);
        grid.add(fullNameField, 1, 2);

        grid.add(new Label("Email:"), 0, 3);
        grid.add(emailField, 1, 3);

        grid.add(new Label("Роль*:"), 0, 4);
        grid.add(roleCombo, 1, 4);

        grid.add(new Label("Статус:"), 0, 5);
        grid.add(activeCheckBox, 1, 5);

        grid.add(errorLabel, 0, 6, 2, 1);

        // Кнопки диалога
        ButtonType saveButtonType = new ButtonType("Сохранить", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        // Настраиваем кнопку сохранения
        Button saveButton = (Button) dialog.getDialogPane().lookupButton(saveButtonType);
        saveButton.setOnAction(event -> {
            if (!validateUserInput(usernameField, passwordField, fullNameField,
                    emailField, roleCombo, errorLabel, user == null)) {
                event.consume();
            }
        });

        dialog.getDialogPane().setContent(grid);
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                try {
                    if (user == null) {
                        // Создание нового пользователя
                        User newUser = userService.registerUser(
                                usernameField.getText().trim(),
                                passwordField.getText().trim(),
                                roleCombo.getValue(),
                                fullNameField.getText().trim(),
                                emailField.getText().trim()
                        );
                        newUser.setIsActive(activeCheckBox.isSelected());
                        return newUser;
                    } else {
                        // Обновление существующего
                        user.setFullName(fullNameField.getText().trim());
                        user.setEmail(emailField.getText().trim());
                        user.setRole(roleCombo.getValue());
                        user.setIsActive(activeCheckBox.isSelected());

                        // Обновляем пароль только если указан новый
                        if (!passwordField.getText().trim().isEmpty()) {
                            // TODO: Реализовать обновление пароля
                            // userService.updatePassword(user.getId(), passwordField.getText().trim());
                        }

                        userService.updateUser(user);
                        return user;
                    }
                } catch (Exception e) {
                    errorLabel.setText("Ошибка сохранения: " + e.getMessage());
                    return null;
                }
            }
            return null;
        });

        // Показываем диалог и обрабатываем результат
        Optional<User> result = dialog.showAndWait();
        result.ifPresent(savedUser -> {
            if (user == null) {
                // Добавляем нового пользователя в список
                userList.add(savedUser);
                showAlert(Alert.AlertType.INFORMATION,
                        "Пользователь добавлен",
                        "Новый пользователь успешно создан.");
            } else {
                // Обновляем таблицу
                usersTable.refresh();
                showAlert(Alert.AlertType.INFORMATION,
                        "Пользователь обновлен",
                        "Данные пользователя успешно сохранены.");
            }
            updateStatistics();
        });
    }

    private boolean validateUserInput(TextField usernameField, PasswordField passwordField,
                                      TextField fullNameField, TextField emailField,
                                      ComboBox<UserRole> roleCombo, Label errorLabel,
                                      boolean isNewUser) {
        errorLabel.setText("");

        // Проверка логина
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            errorLabel.setText("Введите логин пользователя");
            usernameField.requestFocus();
            return false;
        }

        if (username.length() < 3) {
            errorLabel.setText("Логин должен содержать минимум 3 символа");
            usernameField.requestFocus();
            return false;
        }

        // Проверка уникальности логина (только для нового пользователя)
        if (isNewUser) {
            boolean usernameExists = userService.getAllUsers().stream()
                    .anyMatch(u -> username.equalsIgnoreCase(u.getUsername()));

            if (usernameExists) {
                errorLabel.setText("Пользователь с таким логином уже существует");
                usernameField.requestFocus();
                return false;
            }
        }

        // Проверка пароля (для нового пользователя)
        if (isNewUser && passwordField.getText().trim().isEmpty()) {
            errorLabel.setText("Введите пароль");
            passwordField.requestFocus();
            return false;
        }

        if (isNewUser && passwordField.getText().trim().length() < 6) {
            errorLabel.setText("Пароль должен содержать минимум 6 символов");
            passwordField.requestFocus();
            return false;
        }

        // Проверка ФИО
        if (fullNameField.getText().trim().isEmpty()) {
            errorLabel.setText("Введите ФИО пользователя");
            fullNameField.requestFocus();
            return false;
        }

        // Проверка email (опционально)
        String email = emailField.getText().trim();
        if (!email.isEmpty() && !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            errorLabel.setText("Введите корректный email адрес");
            emailField.requestFocus();
            return false;
        }

        // Проверка роли
        if (roleCombo.getValue() == null) {
            errorLabel.setText("Выберите роль пользователя");
            roleCombo.requestFocus();
            return false;
        }

        return true;
    }

    // ================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==================
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Метод для получения текущего пользователя (для проверки прав)
    public boolean isAdminUser() {
        // TODO: Реализовать получение текущего пользователя
        // Временно возвращаем true для тестирования
        return true;
    }
}