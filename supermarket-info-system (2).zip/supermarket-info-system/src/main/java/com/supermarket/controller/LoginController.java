package com.supermarket.controller;

import com.supermarket.model.User;
import com.supermarket.service.UserService;
import com.supermarket.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label statusLabel;

    private final UserService userService = new UserService();

    @FXML
    private void initialize() {
        // Очистка статуса при изменении текста
        usernameField.textProperty().addListener((obs, oldVal, newVal) -> clearStatus());
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> clearStatus());
    }

    private void clearStatus() {
        statusLabel.setText("");
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        // Валидация
        if (username.isEmpty() || password.isEmpty()) {
            showError("Заполните все поля");
            return;
        }

        try {
            // Аутентификация
            var userOpt = userService.authenticate(username, password);

            if (userOpt.isPresent()) {
                User user = userOpt.get();

                // Сохраняем пользователя в сессии
                SessionManager.getInstance().setCurrentUser(user);

                showSuccess("Вход выполнен успешно!");
                openMainWindow(user);
            } else {
                showError("Неверный логин или пароль");
            }

        } catch (Exception e) {
            showError("Ошибка при входе: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void openMainWindow(User user) {
        System.out.println("DEBUG: openMainWindow вызван для пользователя: " + user.getUsername() + " с ролью: " + user.getRole());

        try {
            // 1. Проверяем существование файла
            System.out.println("DEBUG: Проверяем путь к main.fxml...");
            java.net.URL url = getClass().getResource("/fxml/main.fxml");
            if (url == null) {
                System.err.println("ERROR: Файл main.fxml не найден!");
                System.err.println("Проверьте путь: /fxml/main.fxml");
                showError("Ошибка: файл main.fxml не найден");
                return;
            }
            System.out.println("DEBUG: Файл найден: " + url.getPath());

            // 2. Закрываем окно входа
            System.out.println("DEBUG: Закрываем окно входа...");
            Stage currentStage = (Stage) usernameField.getScene().getWindow();
            currentStage.close();

            // 3. Загружаем главное окно
            System.out.println("DEBUG: Загружаем main.fxml...");
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();
            System.out.println("DEBUG: main.fxml загружен успешно");

            // 4. Настраиваем контроллер
            MainController mainController = loader.getController();
            if (mainController == null) {
                System.err.println("ERROR: MainController не найден в main.fxml!");
                showError("Ошибка: контроллер не найден");
                return;
            }

            // Передаем пользователя в MainController
            mainController.initializeForUser(user);

            // 5. Создаем и показываем новое окно
            System.out.println("DEBUG: Создаем главное окно...");
            Stage mainStage = new Stage();
            Scene scene = new Scene(root, 1200, 800);
            mainStage.setScene(scene);
            mainStage.setTitle("Информационно-справочная система - " +
                    user.getFullName() + " (" +
                    user.getRole().getDisplayName() + ")");
            mainStage.setMinWidth(900);
            mainStage.setMinHeight(600);

            mainStage.show();
            System.out.println("DEBUG: Главное окно показано");

        } catch (Exception e) {
            System.err.println("ERROR: Ошибка при открытии главного окна:");
            e.printStackTrace();

            // Показываем подробную ошибку
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setHeaderText("Не удалось открыть главное окно");
            alert.setContentText("Ошибка: " + e.getMessage() +
                    "\n\nПроверьте:\n" +
                    "1. Существует ли файл main.fxml\n" +
                    "2. Корректность FXML разметки\n" +
                    "3. Наличие контроллера MainController");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleCancel() {
        // Закрываем окно входа
        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleRegister() {
        try {
            System.out.println("DEBUG: Открытие формы регистрации...");

            // Пробуем несколько возможных путей к файлу регистрации
            java.net.URL url = null;
            String[] possiblePaths = {
                    "/fxml/registration.fxml",      // ваш файл
                    "/com/supermarket/view/registration.fxml",
                    "/view/registration.fxml",
                    "fxml/registration.fxml",       // без слеша в начале
                    "registration.fxml"             // относительный путь
            };

            for (String path : possiblePaths) {
                url = getClass().getResource(path);
                if (url != null) {
                    System.out.println("DEBUG: Файл регистрации найден по пути: " + path);
                    break;
                }
            }

            if (url == null) {
                // Дополнительная диагностика
                System.err.println("ERROR: Попробуем найти файл другим способом...");
                try {
                    // Пробуем загрузить через ClassLoader
                    url = Thread.currentThread().getContextClassLoader().getResource("fxml/registration.fxml");
                    if (url != null) {
                        System.out.println("DEBUG: Найден через ClassLoader: " + url);
                    }

                    // Пробуем абсолютный путь
                    java.io.File file = new java.io.File("src/main/resources/fxml/registration.fxml");
                    if (file.exists()) {
                        url = file.toURI().toURL();
                        System.out.println("DEBUG: Найден по абсолютному пути: " + url);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            if (url == null) {
                System.err.println("ERROR: Файл registration.fxml не найден!");

                // Показываем диалог с предложением создать файл
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Файл не найден");
                alert.setHeaderText("Файл registration.fxml не найден");
                alert.setContentText("Хотите создать базовую форму регистрации?");

                ButtonType createButton = new ButtonType("Создать");
                ButtonType cancelButton = new ButtonType("Отмена", ButtonBar.ButtonData.CANCEL_CLOSE);
                alert.getButtonTypes().setAll(createButton, cancelButton);

                if (alert.showAndWait().orElse(cancelButton) == createButton) {
                    createRegistrationForm();
                    return;
                }
                return;
            }

            // Загружаем форму регистрации
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            // Получаем текущее окно
            Stage currentStage = (Stage) usernameField.getScene().getWindow();

            // Создаем новое окно для регистрации
            Stage registerStage = new Stage();
            registerStage.setTitle("Регистрация нового пользователя");
            registerStage.setScene(new Scene(root, 500, 450));
            registerStage.initOwner(currentStage);

            registerStage.show();
            System.out.println("DEBUG: Окно регистрации успешно открыто");

        } catch (Exception e) {
            System.err.println("ERROR: Ошибка при открытии регистрации:");
            e.printStackTrace();

            showAlert(Alert.AlertType.ERROR, "Ошибка",
                    "Не удалось открыть форму регистрации: " + e.getMessage());
        }
    }

    private void createRegistrationForm() {
        try {
            // Создаем базовый FXML файл регистрации
            String fxmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<?import javafx.scene.control.*?>\n" +
                    "<?import javafx.scene.layout.*?>\n" +
                    "<?import javafx.geometry.Insets?>\n" +
                    "<VBox xmlns=\"http://javafx.com/javafx/17\"\n" +
                    "      xmlns:fx=\"http://javafx.com/fxml/1\"\n" +
                    "      fx:controller=\"com.supermarket.controller.RegisterController\"\n" +
                    "      alignment=\"CENTER\" spacing=\"15\"\n" +
                    "      style=\"-fx-background-color: #f5f5f5;\">\n" +
                    "    <padding><Insets top=\"30\" right=\"40\" bottom=\"30\" left=\"40\"/></padding>\n" +
                    "    <Label text=\"Регистрация\" style=\"-fx-font-size: 20px; -fx-font-weight: bold;\"/>\n" +
                    "    <GridPane hgap=\"10\" vgap=\"10\">\n" +
                    "        <columnConstraints>\n" +
                    "            <ColumnConstraints halignment=\"RIGHT\" minWidth=\"100\"/>\n" +
                    "            <ColumnConstraints minWidth=\"200\"/>\n" +
                    "        </columnConstraints>\n" +
                    "        <Label text=\"Логин:\" GridPane.rowIndex=\"0\" GridPane.columnIndex=\"0\"/>\n" +
                    "        <TextField fx:id=\"usernameField\" GridPane.rowIndex=\"0\" GridPane.columnIndex=\"1\"/>\n" +
                    "        <Label text=\"Пароль:\" GridPane.rowIndex=\"1\" GridPane.columnIndex=\"0\"/>\n" +
                    "        <PasswordField fx:id=\"passwordField\" GridPane.rowIndex=\"1\" GridPane.columnIndex=\"1\"/>\n" +
                    "        <Label text=\"Подтверждение:\" GridPane.rowIndex=\"2\" GridPane.columnIndex=\"0\"/>\n" +
                    "        <PasswordField fx:id=\"confirmPasswordField\" GridPane.rowIndex=\"2\" GridPane.columnIndex=\"1\"/>\n" +
                    "        <HBox spacing=\"10\" GridPane.rowIndex=\"3\" GridPane.columnIndex=\"1\">\n" +
                    "            <Button text=\"Регистрация\" onAction=\"#handleRegister\"/>\n" +
                    "            <Button text=\"Отмена\" onAction=\"#handleCancel\"/>\n" +
                    "        </HBox>\n" +
                    "    </GridPane>\n" +
                    "</VBox>";

            // Определяем путь для сохранения
            java.io.File resourcesDir = new java.io.File("src/main/resources/fxml");
            if (!resourcesDir.exists()) {
                resourcesDir.mkdirs();
            }

            java.io.File fxmlFile = new java.io.File(resourcesDir, "registration.fxml");
            java.nio.file.Files.write(fxmlFile.toPath(), fxmlContent.getBytes());

            System.out.println("DEBUG: Файл создан: " + fxmlFile.getAbsolutePath());

            // Теперь открываем созданный файл
            FXMLLoader loader = new FXMLLoader(fxmlFile.toURI().toURL());
            Parent root = loader.load();

            Stage currentStage = (Stage) usernameField.getScene().getWindow();
            Stage registerStage = new Stage();
            registerStage.setTitle("Регистрация");
            registerStage.setScene(new Scene(root, 400, 300));
            registerStage.initOwner(currentStage);
            registerStage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Не удалось создать форму: " + e.getMessage());
        }
    }

    // Метод showRegistration можно удалить или оставить для обратной совместимости
    @FXML
    private void showRegistration() {
        // Для обратной совместимости, вызываем handleRegister
        handleRegister();
    }

    private void showError(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
    }

    private void showSuccess(String message) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}