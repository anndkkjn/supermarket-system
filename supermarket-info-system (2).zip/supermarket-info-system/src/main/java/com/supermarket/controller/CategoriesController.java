package com.supermarket.controller;

import com.supermarket.model.Category;
import com.supermarket.service.CategoryService;
import com.supermarket.util.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.util.Optional;

public class CategoriesController {

    @FXML private TableView<Category> categoriesTable;
    @FXML private TableColumn<Category, Long> idColumn;
    @FXML private TableColumn<Category, String> nameColumn;
    @FXML private TableColumn<Category, String> descriptionColumn;
    @FXML private TableColumn<Category, String> productCountColumn;
    @FXML private TableColumn<Category, String> statusColumn;
    @FXML private Label statsLabel;

    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;
    @FXML private Button toggleActiveButton;

    private final CategoryService categoryService = new CategoryService();
    private final ObservableList<Category> categoryList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        System.out.println("DEBUG: CategoriesController инициализирован");

        // Проверяем права доступа
        if (!checkPermissions()) {
            return;
        }

        setupTableColumns();
        loadData();
        updateStatistics();

        // Отложенная настройка кнопок после загрузки сцены
        configureButtonsForRoleDeferred();
    }

    private boolean checkPermissions() {
        SessionManager session = SessionManager.getInstance();

        if (!session.isAuthenticated()) {
            showAlertAndClose("Ошибка", "Требуется авторизация");
            return false;
        }

        // Проверяем права на управление категориями
        if (!session.isAdmin() && !session.isManager()) {
            showAlertAndClose("Доступ запрещен",
                    "Только администратор или менеджер может управлять категориями");
            return false;
        }

        return true;
    }

    private void configureButtonsForRoleDeferred() {
        // Используем Platform.runLater для отложенного выполнения после загрузки сцены
        javafx.application.Platform.runLater(() -> {
            configureButtonsForRole();
        });
    }

    private void configureButtonsForRole() {
        SessionManager session = SessionManager.getInstance();

        // Проверяем, что кнопки существуют (дополнительная проверка)
        if (addButton == null || deleteButton == null) {
            System.err.println("ERROR: Кнопки не найдены в FXML");
            return;
        }

        // Только администратор или менеджер может управлять категориями
        boolean canManage = session.isAdmin() || session.isManager();

        addButton.setDisable(!canManage);
        deleteButton.setDisable(!canManage);
        if (editButton != null) editButton.setDisable(!canManage);
        if (toggleActiveButton != null) toggleActiveButton.setDisable(!canManage);

        // Обновляем подписи кнопок для пользователя (с проверкой сцены)
        if (categoriesTable != null && categoriesTable.getScene() != null) {
            Stage stage = (Stage) categoriesTable.getScene().getWindow();
            String role = session.getUserRoleName();
            stage.setTitle("Управление категориями - " + role);
        }
    }

    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        // Количество товаров в категории
        productCountColumn.setCellValueFactory(cellData -> {
            Category category = cellData.getValue();
            long count = categoryService.countProductsInCategory(category.getId());
            return new javafx.beans.property.SimpleStringProperty(String.valueOf(count));
        });

        // Статус
        statusColumn.setCellValueFactory(cellData -> {
            Boolean isActive = cellData.getValue().getIsActive();
            return new javafx.beans.property.SimpleStringProperty(
                    Boolean.TRUE.equals(isActive) ? "Активна" : "Неактивна"
            );
        });

        // Настраиваем внешний вид колонки статуса
        statusColumn.setCellFactory(column -> new TableCell<Category, String>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status);
                    if (status.equals("Активна")) {
                        setStyle("-fx-text-fill: #27ae60; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                    }
                }
            }
        });
    }

    private void loadData() {
        try {
            categoryList.clear();
            categoryList.addAll(categoryService.getAllCategories());
            categoriesTable.setItems(categoryList);
            System.out.println("DEBUG: Загружено категорий: " + categoryList.size());
        } catch (Exception e) {
            System.err.println("ERROR: Ошибка загрузки категорий: " + e.getMessage());
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка загрузки");
            alert.setHeaderText(null);
            alert.setContentText("Не удалось загрузить категории: " + e.getMessage());
            alert.showAndWait();
        }
    }

    private void updateStatistics() {
        long totalCategories = categoryList.size();
        long activeCategories = categoryList.stream()
                .filter(c -> Boolean.TRUE.equals(c.getIsActive()))
                .count();

        if (statsLabel != null) {
            statsLabel.setText(String.format(
                    "Категорий: %d (активных: %d)", totalCategories, activeCategories
            ));
        }
    }

    @FXML
    private void handleAddCategory() {
        System.out.println("DEBUG: Добавление категории");

        // Проверяем права
        if (!SessionManager.getInstance().isAdmin() &&
                !SessionManager.getInstance().isManager()) {
            showAlert("Доступ запрещен", "Только администратор или менеджер может добавлять категории");
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Новая категория");
        dialog.setHeaderText("Добавление категории");
        dialog.setContentText("Введите название категории:");

        dialog.showAndWait().ifPresent(name -> {
            if (!name.trim().isEmpty()) {
                try {
                    Category category = categoryService.createCategory(name.trim(), "");
                    categoryList.add(category);
                    updateStatistics();

                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("Успех");
                    success.setHeaderText(null);
                    success.setContentText("Категория добавлена");
                    success.showAndWait();
                } catch (Exception e) {
                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("Ошибка");
                    error.setHeaderText(null);
                    error.setContentText("Не удалось добавить категорию: " + e.getMessage());
                    error.showAndWait();
                }
            }
        });
    }

    @FXML
    private void handleDeleteCategory() {
        System.out.println("DEBUG: Удаление категории");

        Category selected = categoriesTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Проверяем права
            if (!SessionManager.getInstance().isAdmin() &&
                    !SessionManager.getInstance().isManager()) {
                showAlert("Доступ запрещен", "Только администратор или менеджер может удалять категории");
                return;
            }

            // Проверяем, есть ли товары в категории
            long productCount = categoryService.countProductsInCategory(selected.getId());
            if (productCount > 0) {
                Alert warning = new Alert(Alert.AlertType.WARNING);
                warning.setTitle("Невозможно удалить");
                warning.setHeaderText(null);
                warning.setContentText(String.format(
                        "Категория '%s' содержит %d товаров.%n" +
                                "Сначала переместите или удалите товары.",
                        selected.getName(), productCount
                ));
                warning.showAndWait();
                return;
            }

            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            confirmation.setTitle("Подтверждение удаления");
            confirmation.setHeaderText("Удаление категории");
            confirmation.setContentText("Вы уверены, что хотите удалить категорию: " +
                    selected.getName() + "?");

            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    try {
                        categoryService.deleteCategory(selected.getId());
                        categoryList.remove(selected);
                        updateStatistics();

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Категория удалена");
                        success.setHeaderText(null);
                        success.setContentText("Категория успешно удалена.");
                        success.showAndWait();
                    } catch (Exception e) {
                        Alert error = new Alert(Alert.AlertType.ERROR);
                        error.setTitle("Ошибка удаления");
                        error.setHeaderText(null);
                        error.setContentText("Не удалось удалить категорию: " + e.getMessage());
                        error.showAndWait();
                    }
                }
            });
        }
    }

    @FXML
    private void handleEditCategory() {
        Category selected = categoriesTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Проверяем права
            if (!SessionManager.getInstance().isAdmin() &&
                    !SessionManager.getInstance().isManager()) {
                showAlert("Доступ запрещен", "Только администратор или менеджер может редактировать категории");
                return;
            }

            // Диалог редактирования категории
            TextInputDialog dialog = new TextInputDialog(selected.getName());
            dialog.setTitle("Редактирование категории");
            dialog.setHeaderText("Редактирование категории");
            dialog.setContentText("Введите новое название категории:");

            dialog.showAndWait().ifPresent(newName -> {
                if (!newName.trim().isEmpty() && !newName.equals(selected.getName())) {
                    try {
                        selected.setName(newName.trim());
                        categoryService.updateCategory(selected);
                        categoriesTable.refresh();
                        updateStatistics();

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Категория обновлена");
                        success.setHeaderText(null);
                        success.setContentText("Категория успешно обновлена.");
                        success.showAndWait();
                    } catch (Exception e) {
                        Alert error = new Alert(Alert.AlertType.ERROR);
                        error.setTitle("Ошибка обновления");
                        error.setHeaderText(null);
                        error.setContentText("Не удалось обновить категорию: " + e.getMessage());
                        error.showAndWait();
                    }
                }
            });
        }
    }

    @FXML
    private void handleToggleActive() {
        Category selected = categoriesTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            // Проверяем права
            if (!SessionManager.getInstance().isAdmin() &&
                    !SessionManager.getInstance().isManager()) {
                showAlert("Доступ запрещен", "Только администратор или менеджер может изменять статус категорий");
                return;
            }

            try {
                selected.setIsActive(!Boolean.TRUE.equals(selected.getIsActive()));
                categoryService.updateCategory(selected);
                categoriesTable.refresh();
                updateStatistics();

                String status = Boolean.TRUE.equals(selected.getIsActive()) ?
                        "активирована" : "деактивирована";
                showAlert("Статус изменен",
                        "Категория '" + selected.getName() + "' " + status);
            } catch (Exception e) {
                showAlert("Ошибка", "Не удалось изменить статус: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleRefresh() {
        loadData();
        showAlert("Обновлено", "Данные категорий обновлены");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showAlertAndClose(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.setOnHidden(event -> {
            // Безопасная проверка на существование сцены
            if (categoriesTable != null && categoriesTable.getScene() != null) {
                Stage stage = (Stage) categoriesTable.getScene().getWindow();
                stage.close();
            }
        });
        alert.showAndWait();
    }
}