package com.supermarket.controller;

import com.supermarket.model.User;
import com.supermarket.util.SessionManager;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MainController {

    @FXML
    private StackPane contentArea;

    @FXML
    private Label currentUserLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private Label timeLabel;

    private User currentUser;

    public void initializeForUser(User user) {
        this.currentUser = user;
        SessionManager.getInstance().setCurrentUser(user);

        System.out.println("DEBUG: MainController инициализирован для пользователя: " +
                user.getUsername() + " с ролью: " + user.getRole());

        updateUserInfo();
        configureMenuForRole();
        updateStatus("Система запущена");
        updateTime();
        startClock();

        showDefaultContentForRole();
    }

    private void updateUserInfo() {
        if (currentUser != null && currentUserLabel != null) {
            String displayText = currentUser.getFullName() != null ?
                    currentUser.getFullName() : currentUser.getUsername();
            displayText += " (" + currentUser.getRole().getDisplayName() + ")";
            currentUserLabel.setText(displayText);

            switch (currentUser.getRole()) {
                case ADMIN:
                    currentUserLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-weight: bold;");
                    break;
                case MANAGER:
                    currentUserLabel.setStyle("-fx-text-fill: #3498db; -fx-font-weight: bold;");
                    break;
                case CASHIER:
                    currentUserLabel.setStyle("-fx-text-fill: #2ecc71; -fx-font-weight: bold;");
                    break;
            }
        }
    }

    private void configureMenuForRole() {
        if (currentUser == null) return;
        System.out.println("DEBUG: Роль пользователя: " + currentUser.getRole());
        System.out.println("DEBUG: Пункты меню не настроены для разных ролей");
    }

    private void showDefaultContentForRole() {
        if (currentUser == null) {
            showPlaceholder("Не удалось определить пользователя");
            return;
        }

        switch (currentUser.getRole()) {
            case ADMIN:
            case MANAGER:
                showProductsManagement();
                break;
            case CASHIER:
                showPlaceholder("Интерфейс кассира - режим продаж");
                break;
        }
    }

    private void updateStatus(String message) {
        if (statusLabel != null) {
            statusLabel.setText(message);
        }
    }

    private void updateTime() {
        LocalTime now = LocalTime.now();
        if (timeLabel != null) {
            timeLabel.setText(now.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        }
    }

    private void startClock() {
        Timeline clock = new Timeline(
                new KeyFrame(
                        Duration.seconds(1),
                        event -> updateTime()
                )
        );
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }

    // =========== ОБРАБОТЧИКИ МЕНЮ ===========

    @FXML
    private void handleExit() {
        Stage stage = (Stage) contentArea.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void showProductsManagement() {
        if (!SessionManager.getInstance().hasPermission("manage_products") &&
                !SessionManager.getInstance().hasPermission("view_products")) {
            showAccessDeniedAlert();
            return;
        }

        System.out.println("DEBUG: Показываем управление товарами");
        updateStatus("Управление товарами");
        loadFXMLToCenter("/fxml/products_management.fxml");
    }

    @FXML
    private void showCategoriesManagement() {
        if (!SessionManager.getInstance().isAdmin() &&
                !SessionManager.getInstance().isManager()) {
            showAccessDeniedAlert();
            return;
        }

        System.out.println("DEBUG: Показываем управление категориями");
        updateStatus("Управление категориями");
        loadFXMLToCenter("/fxml/categories_management.fxml");
    }

    @FXML
    private void showAdvancedSearch() {
        System.out.println("Показываем расширенный поиск...");
        updateStatus("Расширенный поиск");
        loadFXMLToCenter("/fxml/advanced_search.fxml");
    }

    @FXML
    private void showUsersManagement() {
        if (!SessionManager.getInstance().isAdmin()) {
            showAccessDeniedAlert();
            return;
        }

        System.out.println("DEBUG: Показываем управление пользователями");
        updateStatus("Управление пользователями");
        loadFXMLToCenter("/fxml/users_management.fxml");
    }

    @FXML
    private void showStatistics() {
        System.out.println("DEBUG: Показываем статистику");
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/statistics.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Статистика");
            stage.setScene(new Scene(root, 1000, 700));
            stage.show();

        } catch (IOException e) {
            System.err.println("Ошибка загрузки статистики: " + e.getMessage());
            e.printStackTrace();
            showAlert("Ошибка", "Не удалось загрузить статистику: " + e.getMessage());
        }
    }

    @FXML
    private void handleCheckNotifications() {
        System.out.println("Проверка уведомлений...");

        try {
            com.supermarket.service.NotificationService notificationService =
                    new com.supermarket.service.NotificationService();
            notificationService.performAllChecks();

            // Показать сводку
            Alert summaryAlert = new Alert(Alert.AlertType.INFORMATION);
            summaryAlert.setTitle("Сводка уведомлений");
            summaryAlert.setHeaderText("Результаты проверки");
            summaryAlert.setContentText(notificationService.getNotificationsSummary());
            summaryAlert.showAndWait();

        } catch (Exception e) {
            System.err.println("Ошибка при проверке уведомлений: " + e.getMessage());
            e.printStackTrace();

            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Ошибка");
            errorAlert.setHeaderText("Не удалось проверить уведомления");
            errorAlert.setContentText("Ошибка: " + e.getMessage());
            errorAlert.showAndWait();
        }
    }

    @FXML
    private void handleNotificationsSummary() {
        System.out.println("Показ сводки уведомлений...");

        try {
            com.supermarket.service.NotificationService notificationService =
                    new com.supermarket.service.NotificationService();
            String summary = notificationService.getNotificationsSummary();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Сводка уведомлений");
            alert.setHeaderText("Текущее состояние");
            alert.setContentText(summary);
            alert.setResizable(true);
            alert.getDialogPane().setPrefWidth(400);
            alert.showAndWait();

        } catch (Exception e) {
            System.err.println("Ошибка при получении сводки: " + e.getMessage());

            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Ошибка");
            errorAlert.setHeaderText("Не удалось получить сводку");
            errorAlert.setContentText("Ошибка: " + e.getMessage());
            errorAlert.showAndWait();
        }
    }

    @FXML
    private void showAbout() {
        System.out.println("DEBUG: Показываем информацию о программе");
        updateStatus("О программе");
        showAboutDialog();
    }

    @FXML
    private void showAddProduct() {
        System.out.println("Открытие формы добавления товара");
        try {
            // Загружаем FXML форму добавления товара
            loadFXMLToCenter("/fxml/add_product.fxml");
        } catch (Exception e) {
            System.err.println("Ошибка при открытии формы добавления товара: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка",
                    "Не удалось открыть форму добавления товара: " + e.getMessage());
        }
    }

    @FXML
    private void refreshData() {
        System.out.println("refreshData() вызван - обновление данных");

        try {
            updateStatus("Обновление данных...");

            // Показываем сообщение об обновлении
            Alert infoAlert = new Alert(Alert.AlertType.INFORMATION);
            infoAlert.setTitle("Обновление данных");
            infoAlert.setHeaderText("Данные обновлены");
            infoAlert.setContentText("Все данные успешно обновлены.");
            infoAlert.showAndWait();

            // Если сейчас открыта какая-то форма, можно перезагрузить ее
            if (contentArea.getChildren().size() > 0) {
                // Проверяем, что сейчас открыто
                Node currentContent = contentArea.getChildren().get(0);
                if (currentContent instanceof Label) {
                    Label label = (Label) currentContent;
                    if (label.getText().contains("Управление товарами")) {
                        // Если открыто управление товарами, перезагружаем
                        showProductsManagement();
                    }
                }
            }

            updateStatus("Система готова к работе");
            System.out.println("Данные успешно обновлены");

        } catch (Exception e) {
            System.err.println("Ошибка при обновлении данных: " + e.getMessage());
            e.printStackTrace();

            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Ошибка обновления");
            errorAlert.setHeaderText("Не удалось обновить данные");
            errorAlert.setContentText("Ошибка: " + e.getMessage());
            errorAlert.showAndWait();
        }
    }

    @FXML
    private void showStockChart() {
        System.out.println("DEBUG: Показываем график остатков товаров");
        updateStatus("График остатков товаров");

        try {
            // Проверяем, есть ли файл
            URL fxmlUrl = getClass().getResource("/fxml/stock_chart.fxml");
            if (fxmlUrl == null) {
                System.out.println("Файл stock_chart.fxml не найден, создаем простой график");
                showSimpleStockChart();
                return;
            }

            // Загружаем форму с графиком
            loadFXMLToCenter("/fxml/stock_chart.fxml");

        } catch (Exception e) {
            System.err.println("Ошибка при загрузке графика: " + e.getMessage());
            e.printStackTrace();
            showSimpleStockChart();
        }
    }

    private void showSimpleStockChart() {
        System.out.println("Создаем простой график остатков");

        try {
            // Получаем данные для графика
            com.supermarket.dao.ProductDao productDao = new com.supermarket.dao.ProductDao();

            // Создаем график
            javafx.scene.chart.CategoryAxis xAxis = new javafx.scene.chart.CategoryAxis();
            javafx.scene.chart.NumberAxis yAxis = new javafx.scene.chart.NumberAxis();
            javafx.scene.chart.BarChart<String, Number> chart = new javafx.scene.chart.BarChart<>(xAxis, yAxis);

            chart.setTitle("Остатки товаров");
            xAxis.setLabel("Товары");
            yAxis.setLabel("Количество");

            javafx.scene.chart.XYChart.Series<String, Number> series = new javafx.scene.chart.XYChart.Series<>();
            series.setName("Остатки");

            // Получаем все товары
            List<com.supermarket.model.Product> products = productDao.findAll();
            int count = 0;

            for (com.supermarket.model.Product p : products) {
                if (count < 10) { // Показываем только первые 10 товаров
                    String displayName = p.getName();
                    if (displayName.length() > 15) {
                        displayName = displayName.substring(0, 12) + "...";
                    }
                    series.getData().add(new javafx.scene.chart.XYChart.Data<>(displayName, p.getQuantity()));
                    count++;
                }
            }

            chart.getData().add(series);
            chart.setPrefSize(800, 500);

            // Создаем контейнер
            javafx.scene.layout.VBox container = new javafx.scene.layout.VBox(10);
            container.setPadding(new javafx.geometry.Insets(10));

            javafx.scene.control.Label titleLabel = new javafx.scene.control.Label("📊 График остатков товаров");
            titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

            javafx.scene.control.Label infoLabel = new javafx.scene.control.Label(
                    String.format("Всего товаров: %d | Показано: %d", products.size(), Math.min(products.size(), 10))
            );

            container.getChildren().addAll(titleLabel, infoLabel, chart);

            // Добавляем в основную область
            contentArea.getChildren().clear();
            contentArea.getChildren().add(container);

            updateStatus("График остатков загружен");

        } catch (Exception e) {
            System.err.println("Ошибка при создании графика: " + e.getMessage());
            e.printStackTrace();
            showPlaceholder("Не удалось создать график: " + e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        System.out.println("DEBUG: Выход из системы");

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Подтверждение выхода");
        confirm.setHeaderText("Выход из системы");
        confirm.setContentText("Вы уверены, что хотите выйти?");

        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    SessionManager.getInstance().logout();
                    Stage currentStage = (Stage) contentArea.getScene().getWindow();
                    currentStage.close();

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
                    Parent root = loader.load();

                    Stage loginStage = new Stage();
                    loginStage.setScene(new Scene(root, 400, 400));
                    loginStage.setTitle("Вход в систему - Продуктовый магазин");
                    loginStage.setResizable(false);
                    loginStage.show();

                } catch (IOException e) {
                    showAlert("Ошибка", "Не удалось открыть окно входа: " + e.getMessage());
                }
            }
        });
    }

    // =========== ЗАГРУЗКА FXML ФАЙЛОВ ===========

    private void loadFXMLToCenter(String fxmlPath) {
        try {
            System.out.println("DEBUG: Загружаем " + fxmlPath);
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent content = loader.load();
            contentArea.getChildren().clear();
            contentArea.getChildren().add(content);
            System.out.println("DEBUG: " + fxmlPath + " загружен успешно");

        } catch (IOException e) {
            System.err.println("ERROR: Не удалось загрузить " + fxmlPath);
            e.printStackTrace();
            showAlert("Ошибка загрузки", "Не удалось загрузить: " + fxmlPath +
                    "\nОшибка: " + e.getMessage());
            showPlaceholder("Ошибка загрузки: " + fxmlPath);
        } catch (Exception e) {
            System.err.println("ERROR: Общая ошибка при загрузке " + fxmlPath);
            e.printStackTrace();
            showPlaceholder("Ошибка: " + e.getMessage());
        }
    }

    // =========== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ===========

    private void showPlaceholder(String text) {
        contentArea.getChildren().clear();
        Label placeholder = new Label(text + "\n\n(Функциональность в разработке)");
        placeholder.setStyle("-fx-font-size: 14pt; -fx-text-fill: gray; -fx-alignment: center;");
        contentArea.getChildren().add(placeholder);
    }

    private void showAboutDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("О программе");
        alert.setHeaderText("Информационно-справочная система продуктового магазина");
        alert.setContentText(
                "Версия: 1.0\n" +
                        "Автор: Новожилова Анна Александровна\n" +
                        "Группа: ПИ23-1в\n" +
                        "Учебное заведение: Финансовый университет при Правительстве Российской Федерации\n" +
                        "Контактные данные: 234268@edu.fa.ru\n\n" +
                        "Работа с технологиями:\n" +
                        "Java 17 + JavaFX + Hibernate + H2 + Maven\n" +
                        "Backend: Java 17, Hibernate, SQL, Maven  \n" +
                        "Frontend: JavaFX (FXML, TableView, Charts), CSS, MVC/MVVM  \n" +
                        "Архитектура: DAO паттерн, слоистая архитектура  \n" +
                        "Решено: N+1 проблема (JOIN FETCH), динамические запросы, BigDecimal для цен, валидация форм, фильтрация данных\n" +
                        "Даты работы над проектом:\n" +
                        "01.09.2025 - 10.12.2025\n\n" +
                        "Используемые технологии: Java, JavaFX, Hibernate, PostgreSQL \n" +
                        "© 2025 Все права защищены."
        );
        alert.setResizable(true);
        alert.getDialogPane().setPrefWidth(600);
        alert.showAndWait();
    }

    // Методы для показа алертов - ДОБАВЬТЕ ЭТИ ДВА МЕТОДА:
    private void showAlert(String title, String message) {
        showAlert(Alert.AlertType.INFORMATION, title, message);
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showAccessDeniedAlert() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Доступ запрещен");
        alert.setHeaderText("Недостаточно прав");
        alert.setContentText("У вас нет прав для доступа к этому разделу.");
        alert.showAndWait();
    }

    public void clearContent() {
        contentArea.getChildren().clear();
    }

    public void addContent(Parent content) {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(content);
    }
}