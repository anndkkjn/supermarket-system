package com.supermarket.controller;

import com.supermarket.model.Product;
import com.supermarket.model.Category;
import com.supermarket.service.ProductService;
import com.supermarket.service.CategoryService;
import com.supermarket.util.SessionManager;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Comparator;
import java.util.Optional;

public class ProductsController {

    // ================== FXML ЭЛЕМЕНТЫ ==================
    @FXML private BorderPane productsPane;
    @FXML private TableView<Product> productsTable;
    @FXML private TableColumn<Product, Long> idColumn;
    @FXML private TableColumn<Product, String> nameColumn;
    @FXML private TableColumn<Product, String> categoryColumn;
    @FXML private TableColumn<Product, BigDecimal> priceColumn;
    @FXML private TableColumn<Product, Integer> quantityColumn;
    @FXML private TableColumn<Product, String> unitColumn;
    @FXML private TableColumn<Product, String> manufacturerColumn;
    @FXML private TableColumn<Product, String> statusColumn;
    @FXML private TableColumn<Product, String> lastUpdatedColumn;

    @FXML private TextField searchField;
    @FXML private ComboBox<String> searchTypeComboBox;
    @FXML private ComboBox<String> sortComboBox;
    @FXML private ComboBox<String> categoryFilterComboBox;
    @FXML private Label totalProductsLabel;
    @FXML private Label totalValueLabel;
    @FXML private Label lowStockLabel;
    @FXML private Label userInfoLabel;  // Может быть null

    @FXML private Button addButton;
    @FXML private Button editButton;
    @FXML private Button deleteButton;
    @FXML private Button refreshButton;
    @FXML private Button lowStockButton;
    @FXML private Button exportButton;

    // ================== СЕРВИСЫ И ДАННЫЕ ==================
    private final ProductService productService = new ProductService();
    private final CategoryService categoryService = new CategoryService();
    private final ObservableList<Product> productList = FXCollections.observableArrayList();
    private final FilteredList<Product> filteredProducts = new FilteredList<>(productList);
    private final ObservableList<String> categories = FXCollections.observableArrayList("Все категории");

    // ================== ИНИЦИАЛИЗАЦИЯ ==================
    @FXML
    private void initialize() {
        System.out.println("DEBUG: ProductsController инициализирован");

        // Проверяем права доступа
        if (!checkPermissions()) {
            return;
        }

        setupTableColumns();
        setupSearchAndFilters();
        loadData();
        setupTableSelection();
        updateStatistics();
        setupUserInfo();

        // Откладываем настройку кнопок до полной загрузки сцены
        configureButtonsForRoleDeferred();
    }

    private boolean checkPermissions() {
        SessionManager session = SessionManager.getInstance();

        if (!session.isAuthenticated()) {
            showAlertAndClose("Ошибка", "Требуется авторизация");
            return false;
        }

        // Все авторизованные пользователи могут просматривать товары
        if (!session.hasPermission("manage_products") && !session.hasPermission("view_products")) {
            showAlertAndClose("Доступ запрещен",
                    "У вас нет прав для просмотра товаров");
            return false;
        }

        return true;
    }

    private void setupUserInfo() {
        SessionManager session = SessionManager.getInstance();
        if (session.isAuthenticated() && userInfoLabel != null) {
            userInfoLabel.setText(session.getUserFullName() + " (" + session.getUserRoleName() + ")");
        }
    }

    private void configureButtonsForRoleDeferred() {
        // Используем Platform.runLater для отложенного выполнения после загрузки сцены
        javafx.application.Platform.runLater(() -> {
            configureButtonsForRole();
        });
    }

    private void configureButtonsForRole() {
        SessionManager session = SessionManager.getInstance();

        // Настройка видимости и доступности кнопок в зависимости от роли
        boolean canEdit = session.isAdmin() || session.isManager(); // Админ и менеджер могут редактировать
        boolean canDelete = session.isAdmin(); // Только админ может удалять

        // Проверяем, что кнопки существуют перед настройкой
        if (addButton != null) addButton.setDisable(!canEdit);
        if (editButton != null) editButton.setDisable(!canEdit);
        if (deleteButton != null) deleteButton.setDisable(!canDelete);

        // Для кассира кнопки редактирования скрыты
        if (session.isCashier()) {
            if (addButton != null) addButton.setVisible(false);
            if (editButton != null) editButton.setVisible(false);
            if (deleteButton != null) deleteButton.setVisible(false);
            if (exportButton != null) exportButton.setVisible(false);
        }

        // Обновляем заголовок окна (теперь проверяем что сцена существует)
        if (productsTable != null && productsTable.getScene() != null) {
            Stage stage = (Stage) productsTable.getScene().getWindow();
            String role = session.getUserRoleName();
            String title = "Управление товарами";

            if (session.isCashier()) {
                title = "Просмотр товаров (режим кассира)";
            }

            stage.setTitle(title + " - " + role);
        }
    }

    // ================== НАСТРОЙКА ТАБЛИЦЫ ==================
    private void setupTableColumns() {
        // ID
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setComparator(Comparator.naturalOrder());

        // Название
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        // Категория
        categoryColumn.setCellValueFactory(cellData -> {
            Category category = cellData.getValue().getCategory();
            return new SimpleObjectProperty<>(category != null ? category.getName() : "Без категории");
        });

        // Цена с форматированием
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceColumn.setCellFactory(new Callback<TableColumn<Product, BigDecimal>, TableCell<Product, BigDecimal>>() {
            @Override
            public TableCell<Product, BigDecimal> call(TableColumn<Product, BigDecimal> param) {
                return new TableCell<Product, BigDecimal>() {
                    @Override
                    protected void updateItem(BigDecimal price, boolean empty) {
                        super.updateItem(price, empty);
                        if (empty || price == null) {
                            setText(null);
                        } else {
                            setText(String.format("%,.2f ₽", price));
                        }
                    }
                };
            }
        });

        // Количество с цветовой индикацией
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityColumn.setCellFactory(new Callback<TableColumn<Product, Integer>, TableCell<Product, Integer>>() {
            @Override
            public TableCell<Product, Integer> call(TableColumn<Product, Integer> param) {
                return new TableCell<Product, Integer>() {
                    @Override
                    protected void updateItem(Integer quantity, boolean empty) {
                        super.updateItem(quantity, empty);
                        if (empty || quantity == null) {
                            setText(null);
                            setStyle("");
                        } else {
                            setText(quantity.toString());

                            // Проверяем минимальный запас
                            Product product = getTableView().getItems().get(getIndex());
                            Integer minStock = product.getMinStockLevel();

                            if (minStock != null && quantity <= minStock) {
                                if (quantity == 0) {
                                    setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                                } else if (quantity <= minStock * 0.3) {
                                    setStyle("-fx-text-fill: orange; -fx-font-weight: bold;");
                                } else {
                                    setStyle("-fx-text-fill: #e67e22;");
                                }
                            } else {
                                setStyle("");
                            }
                        }
                    }
                };
            }
        });

        // Единица измерения
        unitColumn.setCellValueFactory(new PropertyValueFactory<>("unit"));

        // Производитель
        manufacturerColumn.setCellValueFactory(new PropertyValueFactory<>("manufacturer"));

        // Статус (в наличии/нет)
        statusColumn.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(
                        cellData.getValue().getQuantity() > 0 ? "В наличии" : "Нет в наличии"
                )
        );
        statusColumn.setCellFactory(new Callback<TableColumn<Product, String>, TableCell<Product, String>>() {
            @Override
            public TableCell<Product, String> call(TableColumn<Product, String> param) {
                return new TableCell<Product, String>() {
                    @Override
                    protected void updateItem(String status, boolean empty) {
                        super.updateItem(status, empty);
                        if (empty || status == null) {
                            setText(null);
                            setStyle("");
                        } else {
                            setText(status);
                            if (status.equals("В наличии")) {
                                setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                            } else {
                                setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                            }
                        }
                    }
                };
            }
        });

        // Дата обновления
        lastUpdatedColumn.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(
                        cellData.getValue().getUpdatedAt().format(
                                DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT)
                        )
                )
        );
    }

    // ================== НАСТРОЙКА ПОИСКА И ФИЛЬТРОВ ==================
    private void setupSearchAndFilters() {
        // Настройка ComboBox для типа поиска
        if (searchTypeComboBox != null) {
            searchTypeComboBox.getItems().addAll(
                    "Везде",
                    "По названию",
                    "По производителю",
                    "По штрих-коду",
                    "По описанию"
            );
            searchTypeComboBox.setValue("Везде");
        }

        // Настройка ComboBox для сортировки
        if (sortComboBox != null) {
            sortComboBox.getItems().addAll(
                    "По умолчанию (ID)",
                    "По названию (А-Я)",
                    "По названию (Я-А)",
                    "По цена (возр.)",
                    "По цене (убыв.)",
                    "По количеству (возр.)",
                    "По количеству (убыв.)",
                    "По дате обновления"
            );
            sortComboBox.setValue("По умолчанию (ID)");
            sortComboBox.setOnAction(e -> applySorting());
        }

        // Настройка фильтра по категориям
        if (categoryFilterComboBox != null) {
            categoryFilterComboBox.setItems(categories);
            categoryFilterComboBox.setValue("Все категории");
            categoryFilterComboBox.setOnAction(e -> applyFilters());
        }

        // Настройка поиска - обработка в реальном времени
        if (searchField != null) {
            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                applyFilters();
            });
        }

        if (searchTypeComboBox != null) {
            searchTypeComboBox.setOnAction(e -> applyFilters());
        }

        // Настройка фильтрации и сортировки для таблицы
        SortedList<Product> sortedProducts = new SortedList<>(filteredProducts);
        sortedProducts.comparatorProperty().bind(productsTable.comparatorProperty());
        productsTable.setItems(sortedProducts);
    }

    // ================== ЗАГРУЗКА ДАННЫХ ==================
    private void loadData() {
        try {
            System.out.println("DEBUG: Загрузка данных товаров...");

            // Загрузка товаров
            productList.clear();
            productList.addAll(productService.getAllProducts());
            System.out.println("DEBUG: Загружено товаров: " + productList.size());

            // Загрузка категорий для фильтра
            categories.clear();
            categories.add("Все категории");
            categoryService.getAllCategories().forEach(category ->
                    categories.add(category.getName())
            );
            System.out.println("DEBUG: Загружено категорий: " + (categories.size() - 1));

            // Обновление статистики
            updateStatistics();

        } catch (Exception e) {
            System.err.println("ERROR: Ошибка загрузки данных товаров: " + e.getMessage());
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка загрузки");
            alert.setHeaderText(null);
            alert.setContentText("Не удалось загрузить данные товаров: " + e.getMessage());
            alert.showAndWait();
        }
    }

    // ================== ОБНОВЛЕНИЕ СТАТИСТИКИ ==================
    private void updateStatistics() {
        long totalProducts = productList.size();
        long inStock = productList.stream()
                .filter(p -> p.getQuantity() > 0)
                .count();
        long lowStockCount = productList.stream()
                .filter(p -> {
                    Integer minStock = p.getMinStockLevel();
                    return minStock != null && p.getQuantity() <= minStock && p.getQuantity() > 0;
                })
                .count();
        long outOfStock = productList.stream()
                .filter(p -> p.getQuantity() == 0)
                .count();

        // Общая стоимость товаров на складе
        BigDecimal totalValue = productList.stream()
                .map(p -> p.getPrice().multiply(BigDecimal.valueOf(p.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        if (totalProductsLabel != null) {
            totalProductsLabel.setText(String.format("Товаров: %d", totalProducts));
        }

        if (totalValueLabel != null) {
            totalValueLabel.setText(String.format("Общая стоимость: %,.2f ₽", totalValue));
        }

        if (lowStockLabel != null) {
            lowStockLabel.setText(String.format("Мало на складе: %d | Нет в наличии: %d",
                    lowStockCount, outOfStock));

            // Цветовая индикация для метки низкого запаса
            if (lowStockCount > 5 || outOfStock > 3) {
                lowStockLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
            } else if (lowStockCount > 2 || outOfStock > 1) {
                lowStockLabel.setStyle("-fx-text-fill: orange; -fx-font-weight: bold;");
            } else {
                lowStockLabel.setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
            }
        }
    }

    // ================== ФИЛЬТРАЦИЯ И СОРТИРОВКА ==================
    private void applyFilters() {
        filteredProducts.setPredicate(product -> {
            // Фильтр по категории
            String selectedCategory = categoryFilterComboBox != null ? categoryFilterComboBox.getValue() : null;
            if (selectedCategory != null && !selectedCategory.equals("Все категории")) {
                Category category = product.getCategory();
                if (category == null || !category.getName().equals(selectedCategory)) {
                    return false;
                }
            }

            // Фильтр по поиску
            String searchText = searchField != null ? searchField.getText().toLowerCase() : "";
            if (searchText == null || searchText.isEmpty()) {
                return true;
            }

            String searchType = searchTypeComboBox != null ? searchTypeComboBox.getValue() : "Везде";
            switch (searchType) {
                case "По названию":
                    return product.getName().toLowerCase().contains(searchText);
                case "По производителю":
                    return product.getManufacturer() != null &&
                            product.getManufacturer().toLowerCase().contains(searchText);
                case "По штрих-коду":
                    return product.getBarcode() != null &&
                            product.getBarcode().toLowerCase().contains(searchText);
                case "По описанию":
                    return product.getDescription() != null &&
                            product.getDescription().toLowerCase().contains(searchText);
                case "Везде":
                default:
                    return product.getName().toLowerCase().contains(searchText) ||
                            (product.getManufacturer() != null &&
                                    product.getManufacturer().toLowerCase().contains(searchText)) ||
                            (product.getBarcode() != null &&
                                    product.getBarcode().toLowerCase().contains(searchText)) ||
                            (product.getDescription() != null &&
                                    product.getDescription().toLowerCase().contains(searchText));
            }
        });

        updateStatistics();
    }

    private void applySorting() {
        if (sortComboBox == null) return;

        String sortType = sortComboBox.getValue();

        switch (sortType) {
            case "По названию (А-Я)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(nameColumn);
                nameColumn.setSortType(TableColumn.SortType.ASCENDING);
                break;
            case "По названию (Я-А)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(nameColumn);
                nameColumn.setSortType(TableColumn.SortType.DESCENDING);
                break;
            case "По цене (возр.)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(priceColumn);
                priceColumn.setSortType(TableColumn.SortType.ASCENDING);
                break;
            case "По цена (убыв.)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(priceColumn);
                priceColumn.setSortType(TableColumn.SortType.DESCENDING);
                break;
            case "По количеству (возр.)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(quantityColumn);
                quantityColumn.setSortType(TableColumn.SortType.ASCENDING);
                break;
            case "По количеству (убыв.)":
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(quantityColumn);
                quantityColumn.setSortType(TableColumn.SortType.DESCENDING);
                break;
            case "По дате обновления":
                productsTable.getSortOrder().clear();
                if (lastUpdatedColumn != null) {
                    productsTable.getSortOrder().add(lastUpdatedColumn);
                    lastUpdatedColumn.setSortType(TableColumn.SortType.DESCENDING);
                }
                break;
            case "По умолчанию (ID)":
            default:
                productsTable.getSortOrder().clear();
                productsTable.getSortOrder().add(idColumn);
                idColumn.setSortType(TableColumn.SortType.ASCENDING);
                break;
        }
    }

    // ================== НАСТРОЙКА ВЫБОРА В ТАБЛИЦЕ ==================
    private void setupTableSelection() {
        productsTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    boolean isSelected = newValue != null;

                    // Проверяем права на редактирование
                    SessionManager session = SessionManager.getInstance();
                    boolean canEdit = session.isAdmin() || session.isManager();

                    if (editButton != null) editButton.setDisable(!isSelected || !canEdit);
                    if (deleteButton != null) deleteButton.setDisable(!isSelected || !session.isAdmin());
                }
        );

        // Двойной клик для редактирования
        productsTable.setRowFactory(tv -> {
            TableRow<Product> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    handleEditProduct();
                }
            });
            return row;
        });
    }

    // ================== ОБРАБОТЧИКИ ДЕЙСТВИЙ ==================
    @FXML
    private void handleAddProduct() {
        System.out.println("DEBUG: Добавление нового товара");

        // Проверяем права
        if (!SessionManager.getInstance().hasPermission("manage_products")) {
            showAccessDeniedAlert();
            return;
        }

        showProductDialog(null);
    }

    @FXML
    private void handleEditProduct() {
        // Проверяем права
        if (!SessionManager.getInstance().hasPermission("manage_products")) {
            showAccessDeniedAlert();
            return;
        }

        Product selected = productsTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            System.out.println("DEBUG: Редактирование товара: " + selected.getName());
            showProductDialog(selected);
        }
    }

    @FXML
    private void handleDeleteProduct() {
        // Проверяем права
        if (!SessionManager.getInstance().isAdmin()) {
            showAccessDeniedAlert();
            return;
        }

        Product selected = productsTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
            confirmation.setTitle("Подтверждение удаления");
            confirmation.setHeaderText("Удаление товара");
            confirmation.setContentText("Вы уверены, что хотите удалить товар: " +
                    selected.getName() + "?\n" +
                    "Это действие нельзя отменить.");

            confirmation.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

            confirmation.showAndWait().ifPresent(response -> {
                if (response == ButtonType.YES) {
                    try {
                        productService.deleteProduct(selected.getId());
                        productList.remove(selected);
                        updateStatistics();

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Товар удален");
                        success.setHeaderText(null);
                        success.setContentText("Товар успешно удален из базы данных.");
                        success.showAndWait();

                    } catch (Exception e) {
                        Alert error = new Alert(Alert.AlertType.ERROR);
                        error.setTitle("Ошибка удаления");
                        error.setHeaderText(null);
                        error.setContentText("Не удалось удалить товар: " + e.getMessage());
                        error.showAndWait();
                    }
                }
            });
        }
    }

    @FXML
    private void handleRefresh() {
        System.out.println("DEBUG: Обновление данных");
        loadData();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Данные обновлены");
        alert.setHeaderText(null);
        alert.setContentText("Список товаров успешно обновлен.");
        alert.showAndWait();
    }

    @FXML
    private void handleExport() {
        System.out.println("DEBUG: Экспорт данных");

        // Проверяем права
        if (!SessionManager.getInstance().isAdmin() && !SessionManager.getInstance().isManager()) {
            showAccessDeniedAlert();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Экспорт данных");
        alert.setHeaderText(null);
        alert.setContentText("Функция экспорта будет реализована в следующей версии.");
        alert.showAndWait();
    }

    @FXML
    private void handleShowLowStock() {
        System.out.println("DEBUG: Показ товаров с низким запасом");

        // Проверяем права (все авторизованные могут видеть)
        if (!SessionManager.getInstance().isAuthenticated()) {
            showAccessDeniedAlert();
            return;
        }

        // Фильтрация товаров с низким запасом
        if (categoryFilterComboBox != null) {
            categoryFilterComboBox.setValue("Все категории");
        }
        if (searchField != null) {
            searchField.clear();
        }
        if (searchTypeComboBox != null) {
            searchTypeComboBox.setValue("Везде");
        }

        filteredProducts.setPredicate(product -> {
            Integer minStock = product.getMinStockLevel();
            return minStock != null && product.getQuantity() <= minStock;
        });

        updateStatistics();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Товары с низким запасом");
        alert.setHeaderText(null);
        alert.setContentText("Показаны только товары, количество которых ниже минимального запаса.");
        alert.showAndWait();
    }

    @FXML
    private void handleClearFilters() {
        System.out.println("DEBUG: Очистка фильтров");
        if (categoryFilterComboBox != null) {
            categoryFilterComboBox.setValue("Все категории");
        }
        if (searchField != null) {
            searchField.clear();
        }
        if (searchTypeComboBox != null) {
            searchTypeComboBox.setValue("Везде");
        }
        applyFilters();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Фильтры очищены");
        alert.setHeaderText(null);
        alert.setContentText("Все фильтры сброшены.");
        alert.showAndWait();
    }

    // ================== ДИАЛОГОВОЕ ОКНО ДЛЯ ТОВАРА ==================
    private void showProductDialog(Product product) {
        try {
            System.out.println("DEBUG: Открытие диалога товара");

            // Загружаем диалоговое окно
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/product_dialog.fxml"));
            DialogPane dialogPane = loader.load();

            ProductDialogController controller = loader.getController();
            controller.setProduct(product);

            // Передаем информацию о правах доступа
            controller.configureForCurrentUser();

            // Создаем диалог
            Dialog<ButtonType> dialog = new Dialog<>();
            dialog.setDialogPane(dialogPane);
            dialog.setTitle(product == null ? "Добавление товара" : "Редактирование товара");
            dialog.initModality(Modality.APPLICATION_MODAL);

            // Добавляем кнопки
            dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            // Настраиваем кнопку OK
            Button okButton = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
            okButton.setOnAction(event -> {
                if (!controller.validateInput()) {
                    event.consume(); // Не закрываем диалог если валидация не прошла
                }
            });

            // Показываем диалог и ждем результат
            Optional<ButtonType> result = dialog.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                try {
                    Product updatedProduct = controller.getProduct();

                    if (product == null) {
                        // Добавление нового товара
                        productService.saveProduct(updatedProduct);
                        productList.add(updatedProduct);

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Успех");
                        success.setHeaderText(null);
                        success.setContentText("Товар успешно добавлен в базу данных.");
                        success.showAndWait();
                    } else {
                        // Обновление существующего
                        productService.saveProduct(updatedProduct);
                        refreshTable();

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Успех");
                        success.setHeaderText(null);
                        success.setContentText("Товар успешно обновлен.");
                        success.showAndWait();
                    }

                    updateStatistics();

                } catch (IllegalArgumentException e) {
                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("Ошибка валидации");
                    error.setHeaderText(null);
                    error.setContentText(e.getMessage());
                    error.showAndWait();
                } catch (Exception e) {
                    Alert error = new Alert(Alert.AlertType.ERROR);
                    error.setTitle("Ошибка сохранения");
                    error.setHeaderText(null);
                    error.setContentText("Не удалось сохранить товар: " + e.getMessage());
                    error.showAndWait();
                }
            }

        } catch (IOException e) {
            System.err.println("ERROR: Ошибка загрузки диалогового окна: " + e.getMessage());
            e.printStackTrace();

            Alert error = new Alert(Alert.AlertType.ERROR);
            error.setTitle("Ошибка загрузки");
            error.setHeaderText(null);
            error.setContentText("Не удалось загрузить диалоговое окно: " + e.getMessage());
            error.showAndWait();
        }
    }

    // ================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ==================
    private void refreshTable() {
        productsTable.refresh();
    }

    private void showAlertAndClose(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.setOnHidden(event -> {
            // Безопасная проверка на существование сцены
            if (productsTable != null && productsTable.getScene() != null) {
                Stage stage = (Stage) productsTable.getScene().getWindow();
                stage.close();
            }
        });
        alert.showAndWait();
    }

    private void showAccessDeniedAlert() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Доступ запрещен");
        alert.setHeaderText("Недостаточно прав");
        alert.setContentText("У вас нет прав для выполнения этого действия.");
        alert.showAndWait();
    }
}