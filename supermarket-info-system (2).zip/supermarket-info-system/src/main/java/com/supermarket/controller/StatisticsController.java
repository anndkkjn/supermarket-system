package com.supermarket.controller;

import com.supermarket.service.StatisticsService;
import com.supermarket.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

public class StatisticsController {

    @FXML private Label totalProductsLabel;
    @FXML private Label totalValueLabel;
    @FXML private Label lowStockCountLabel;
    @FXML private PieChart categoryPieChart;
    @FXML private BarChart<String, Number> valueBarChart;
    @FXML private TableView<Product> lowStockTable;
    @FXML private TableColumn<Product, String> productNameColumn;
    @FXML private TableColumn<Product, Integer> currentStockColumn;
    @FXML private TableColumn<Product, Integer> minStockColumn;

    private final StatisticsService statisticsService = new StatisticsService();
    private final DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");

    @FXML
    public void initialize() {
        System.out.println("\n==========================================");
        System.out.println("🚀 StatisticsController.initialize() ВЫЗВАН");
        System.out.println("==========================================");

        // Проверка, что FXML элементы загрузились
        checkFxmlElements();

        try {
            setupTableColumns();
            loadStatistics();
            System.out.println("✅ Контроллер успешно инициализирован");
        } catch (Exception e) {
            System.err.println("❌ ОШИБКА в initialize(): " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void checkFxmlElements() {
        System.out.println("📋 Проверка элементов FXML:");
        System.out.println("   totalProductsLabel: " + (totalProductsLabel != null ? "✓" : "✗"));
        System.out.println("   totalValueLabel: " + (totalValueLabel != null ? "✓" : "✗"));
        System.out.println("   lowStockCountLabel: " + (lowStockCountLabel != null ? "✓" : "✗"));
        System.out.println("   categoryPieChart: " + (categoryPieChart != null ? "✓" : "✗"));
        System.out.println("   valueBarChart: " + (valueBarChart != null ? "✓" : "✗"));
        System.out.println("   lowStockTable: " + (lowStockTable != null ? "✓" : "✗"));
        System.out.println("   productNameColumn: " + (productNameColumn != null ? "✓" : "✗"));
        System.out.println("   currentStockColumn: " + (currentStockColumn != null ? "✓" : "✗"));
        System.out.println("   minStockColumn: " + (minStockColumn != null ? "✓" : "✗"));
    }

    private void setupTableColumns() {
        System.out.println("\n⚙️ Настройка колонок таблицы...");
        try {
            productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
            currentStockColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
            minStockColumn.setCellValueFactory(new PropertyValueFactory<>("minStockLevel"));
            System.out.println("✅ Колонки настроены");
        } catch (Exception e) {
            System.err.println("❌ Ошибка настройки колонок: " + e.getMessage());
        }
    }

    private void loadStatistics() {
        System.out.println("\n📊 НАЧАЛО ЗАГРУЗКИ СТАТИСТИКИ");

        try {
            // 1. Получаем общее количество товаров
            System.out.println("1️⃣ Запрашиваем общее количество товаров...");
            int totalProducts = statisticsService.getTotalProducts();
            System.out.println("   Всего товаров в БД: " + totalProducts);

            if (totalProductsLabel != null) {
                totalProductsLabel.setText(String.valueOf(totalProducts));
                System.out.println("   ✅ Label 'Всего товаров' обновлен");
            } else {
                System.err.println("   ❌ totalProductsLabel is NULL!");
            }

            // 2. Получаем общую стоимость
            System.out.println("\n2️⃣ Запрашиваем общую стоимость...");
            double totalValue = statisticsService.getTotalInventoryValue();
            System.out.println("   Общая стоимость: " + totalValue + " ₽");

            if (totalValueLabel != null) {
                totalValueLabel.setText(decimalFormat.format(totalValue) + " ₽");
                System.out.println("   ✅ Label 'Общая стоимость' обновлен");
            } else {
                System.err.println("   ❌ totalValueLabel is NULL!");
            }

            // 3. Товары с низким запасом
            System.out.println("\n3️⃣ Запрашиваем товары с низким запасом...");
            List<Product> lowStockProducts = statisticsService.getLowStockProducts();
            System.out.println("   Найдено товаров с низким запасом: " + lowStockProducts.size());

            if (lowStockTable != null && lowStockCountLabel != null) {
                ObservableList<Product> observableList = FXCollections.observableArrayList(lowStockProducts);
                lowStockTable.setItems(observableList);
                lowStockCountLabel.setText(String.valueOf(lowStockProducts.size()));
                System.out.println("   ✅ Таблица и Label 'Низкий запас' обновлены");
            } else {
                System.err.println("   ❌ lowStockTable или lowStockCountLabel is NULL!");
            }

            // 4. Загружаем круговую диаграмму
            System.out.println("\n4️⃣ Загружаем круговую диаграмму...");
            loadCategoryPieChart();

            // 5. Загружаем столбчатую диаграмму
            System.out.println("\n5️⃣ Загружаем столбчатую диаграмму...");
            loadValueBarChart();

            System.out.println("\n✅ ВСЯ СТАТИСТИКА УСПЕШНО ЗАГРУЖЕНА");

        } catch (Exception e) {
            System.err.println("\n❌ КРИТИЧЕСКАЯ ОШИБКА при загрузке статистики: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadStockTrendChart() {
        System.out.println("Загрузка графика трендов...");

        // Можно добавить LineChart для отображения изменения остатков
        // Пока просто выводим в консоль
        List<Product> topProducts = statisticsService.getMostExpensiveProducts(5);
        System.out.println("Топ-5 товаров по цене для графика:");
        for (Product p : topProducts) {
            System.out.println("  " + p.getName() + ": " + p.getPrice() + " ₽, остаток: " + p.getQuantity());
        }
    }


    private void loadCategoryPieChart() {
        System.out.println("   Начинаем загрузку круговой диаграммы...");
        try {
            categoryPieChart.getData().clear();
            Map<String, Integer> productsByCategory = statisticsService.getProductsByCategory();
            System.out.println("   Данные для диаграммы: " + productsByCategory);

            if (productsByCategory.isEmpty()) {
                System.out.println("   ⚠️ Нет данных для диаграммы");
                categoryPieChart.setTitle("Нет данных");
                PieChart.Data slice = new PieChart.Data("Нет данных", 1);
                categoryPieChart.getData().add(slice);
            } else {
                for (Map.Entry<String, Integer> entry : productsByCategory.entrySet()) {
                    PieChart.Data slice = new PieChart.Data(
                            entry.getKey() + " (" + entry.getValue() + ")",
                            entry.getValue()
                    );
                    categoryPieChart.getData().add(slice);
                }
                categoryPieChart.setTitle("Распределение товаров по категориям");
                categoryPieChart.setLabelsVisible(true);
                categoryPieChart.setLegendVisible(true);
                System.out.println("   ✅ Круговая диаграмма загружена: " +
                        categoryPieChart.getData().size() + " секторов");
            }
        } catch (Exception e) {
            System.err.println("   ❌ Ошибка загрузки круговой диаграммы: " + e.getMessage());
        }
    }

    private void loadValueBarChart() {
        System.out.println("   Начинаем загрузку столбчатой диаграммы...");
        try {
            valueBarChart.getData().clear();

            // Настраиваем оси
            CategoryAxis xAxis = (CategoryAxis) valueBarChart.getXAxis();
            NumberAxis yAxis = (NumberAxis) valueBarChart.getYAxis();
            xAxis.setLabel("Категории");
            yAxis.setLabel("Стоимость, ₽");

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Стоимость товаров");

            Map<String, Double> categoryValues = statisticsService.getValueByCategory();
            System.out.println("   Данные для диаграммы: " + categoryValues);

            if (categoryValues.isEmpty()) {
                System.out.println("   ⚠️ Нет данных для столбчатой диаграммы");
                series.getData().add(new XYChart.Data<>("Тест", 1000));
            } else {
                for (Map.Entry<String, Double> entry : categoryValues.entrySet()) {
                    series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
                }
            }

            valueBarChart.getData().add(series);
            valueBarChart.setTitle("Стоимость товаров по категориям");
            System.out.println("   ✅ Столбчатая диаграмма загружена: " +
                    series.getData().size() + " столбцов");
        } catch (Exception e) {
            System.err.println("   ❌ Ошибка загрузки столбчатой диаграммы: " + e.getMessage());
        }
    }
}