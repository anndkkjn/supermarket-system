package com.supermarket.controller;

import com.supermarket.dao.ProductDao;
import com.supermarket.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import com.supermarket.dao.CategoryDao;
import java.math.BigDecimal;
import java.math.RoundingMode;

import java.util.List;
import java.util.stream.Collectors;

public class AdvancedSearchController {

    @FXML private TextField nameField;
    @FXML private ComboBox<String> categoryComboBox;
    @FXML private TextField minPriceField;
    @FXML private TextField maxPriceField;
    @FXML private TextField minQuantityField;
    @FXML private ComboBox<String> statusComboBox;
    @FXML private TableView<Product> resultsTable;
    @FXML private TableColumn<Product, String> nameColumn;
    @FXML private TableColumn<Product, String> categoryColumn;
    @FXML private TableColumn<Product, Number> priceColumn;
    @FXML private TableColumn<Product, Integer> quantityColumn;
    @FXML private TableColumn<Product, String> statusColumn;

    private ProductDao productDao = new ProductDao();
    private ObservableList<Product> searchResults = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        System.out.println("=== DEBUG: AdvancedSearchController инициализирован ===");

        // Настройка таблицы
        setupTableColumns();

        // Настройка ComboBox
        statusComboBox.getItems().addAll("Все", "Активные", "Неактивные");
        statusComboBox.setValue("Активные");

        // Загрузка категорий
        loadCategories();

        // Привязка данных таблицы
        resultsTable.setItems(searchResults);

        checkDatabaseData();

        System.out.println("=== DEBUG: Инициализация завершена ===");
    }

    private void checkDatabaseData() {
        System.out.println("=== ПРОВЕРКА ДАННЫХ В БАЗЕ ===");

        try {
            // Проверяем общее количество товаров
            Long totalProducts = productDao.countAllProducts();
            System.out.println("Всего товаров в базе: " + totalProducts);

            // Получаем несколько товаров для примера
            List<Product> sampleProducts = productDao.findAll();
            if (!sampleProducts.isEmpty()) {
                System.out.println("Примеры товаров в базе:");
                for (int i = 0; i < Math.min(sampleProducts.size(), 5); i++) {
                    Product p = sampleProducts.get(i);
                    System.out.println("  " + (i+1) + ". " + p.getName() +
                            ", Категория: " + (p.getCategory() != null ? p.getCategory().getName() : "null") +
                            ", Цена: " + p.getPrice() +
                            ", Количество: " + p.getQuantity());
                }
            } else {
                System.out.println("В базе нет товаров!");
            }

            // Проверяем категории
            CategoryDao categoryDao = new CategoryDao();
            List<String> categories = categoryDao.getAllCategoryNames();
            System.out.println("Категории в базе: " + categories);

        } catch (Exception e) {
            System.err.println("Ошибка при проверке данных: " + e.getMessage());
        }

        System.out.println("=============================");
    }

    private void setupTableColumns() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        categoryColumn.setCellValueFactory(cellData -> {
            Product product = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                    product.getCategory() != null ? product.getCategory().getName() : ""
            );
        });
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        statusColumn.setCellValueFactory(cellData -> {
            Product product = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                    product.isActive() ? "Активен" : "Неактивен"
            );
        });
    }

    private void loadCategories() {
        System.out.println("=== DEBUG: Загрузка категорий из базы ===");

        try {
            // Создаем CategoryDao для получения категорий
            CategoryDao categoryDao = new CategoryDao();
            List<String> categories = categoryDao.getAllCategoryNames();

            System.out.println("Категории из БД: " + categories);

            // Очищаем и добавляем категории
            categoryComboBox.getItems().clear();
            categoryComboBox.getItems().add(""); // Пустое значение для "все категории"
            categoryComboBox.getItems().addAll(categories);
            categoryComboBox.setValue(""); // Устанавливаем пустое значение по умолчанию

            System.out.println("Загружено категорий: " + categories.size());

        } catch (Exception e) {
            System.err.println("Ошибка при загрузке категорий: " + e.getMessage());

            // На случай ошибки используем тестовые данные
            categoryComboBox.getItems().clear();
            categoryComboBox.getItems().addAll("", "Овощи", "Фрукты", "Молочные продукты", "Мясо");
            categoryComboBox.setValue("");
            System.out.println("Используются тестовые категории");
        }
    }
    @FXML
    private void handleSearch() {
        System.out.println("=== DEBUG: Начало handleSearch() ===");
        System.out.println("Выполнение расширенного поиска...");

        try {
            // Получение параметров поиска
            String name = nameField.getText().trim();
            String category = categoryComboBox.getValue();
            Double minPrice = parseDouble(minPriceField.getText().trim());
            Double maxPrice = parseDouble(maxPriceField.getText().trim());
            Integer minQuantity = parseInteger(minQuantityField.getText().trim());
            Boolean activeOnly = getActiveFilter();

            // Отладочный вывод параметров
            System.out.println("=== ПАРАМЕТРЫ ПОИСКА ===");
            System.out.println("Название: '" + name + "' (длина: " + name.length() + ")");
            System.out.println("Категория: '" + category + "'");
            System.out.println("Цена от: " + minPrice);
            System.out.println("Цена до: " + maxPrice);
            System.out.println("Количество от: " + minQuantity);
            System.out.println("Только активные: " + activeOnly);
            System.out.println("==========================");

            // Проверка productDao
            if (productDao == null) {
                System.err.println("ERROR: productDao is null! Создаем новый...");
                productDao = new ProductDao();
            }

            // Выполнение поиска с использованием существующего метода
            System.out.println("Вызываем productDao.searchProductsAdvanced()...");
            List<Product> products = productDao.searchProductsAdvanced(name, category, minPrice, maxPrice, minQuantity);
            System.out.println("Найдено товаров ДО фильтрации по активности: " + products.size());

            // Дополнительная фильтрация по активности
            if (activeOnly != null) {
                products = products.stream()
                        .filter(product -> product.isActive() == activeOnly)
                        .collect(Collectors.toList());
                System.out.println("Найдено товаров ПОСЛЕ фильтрации по активности: " + products.size());
            }

            // Отладочный вывод найденных товаров
            System.out.println("=== НАЙДЕННЫЕ ТОВАРЫ ===");
            if (products.isEmpty()) {
                System.out.println("Товары не найдены!");
            } else {
                for (Product product : products) {
                    System.out.println("- " + product.getName() +
                            ", Категория: " + (product.getCategory() != null ? product.getCategory().getName() : "null") +
                            ", Цена: " + product.getPrice() +
                            ", Количество: " + product.getQuantity() +
                            ", Активен: " + product.isActive());
                }
            }
            System.out.println("========================");

            // Обновление таблицы
            searchResults.setAll(products);
            System.out.println("Таблица обновлена. Элементов в таблице: " + searchResults.size());

            // Показать сообщение о результате
            showAlert(Alert.AlertType.INFORMATION, "Результаты поиска",
                    "Найдено товаров: " + products.size());

        } catch (Exception e) {
            System.err.println("=== ОШИБКА В handleSearch() ===");
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка поиска",
                    "Не удалось выполнить поиск: " + e.getMessage());
        }

        System.out.println("=== DEBUG: Конец handleSearch() ===");
    }

    @FXML
    private void checkDatabase() {
        System.out.println("=== ПРОВЕРКА БАЗЫ ДАННЫХ ===");

        try {
            // 1. Проверим количество товаров
            Long count = productDao.countAllProducts();
            System.out.println("1. Всего товаров в базе: " + count);

            // 2. Получим все товары
            List<Product> allProducts = productDao.findAll();
            System.out.println("2. Найдено через findAll(): " + allProducts.size());

            if (allProducts.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "База данных",
                        "В базе данных нет товаров!");
                return;
            }

            // 3. Покажем первые 10 товаров
            System.out.println("3. Первые 10 товаров:");
            for (int i = 0; i < Math.min(allProducts.size(), 10); i++) {
                Product p = allProducts.get(i);
                System.out.println("   " + (i+1) + ". " + p.getName() +
                        " (ID: " + p.getId() +
                        ", Кат: " + (p.getCategory() != null ? p.getCategory().getName() : "нет") +
                        ", Цена: " + p.getPrice() + ")");
            }

            // 4. Проверим поиск по имени
            System.out.println("4. Тест поиска по имени:");
            for (Product p : allProducts) {
                if (p.getName() != null && p.getName().length() > 3) {
                    String searchTerm = p.getName().substring(0, 3);
                    List<Product> found = productDao.searchByName(searchTerm);
                    System.out.println("   Поиск '" + searchTerm + "': найдено " + found.size());
                    break;
                }
            }

            // 5. Проверка цен (ВЫЗОВ НОВОГО МЕТОДА)
            System.out.println("5. Проверка цен:");
            checkPriceData();

            showAlert(Alert.AlertType.INFORMATION, "Проверка базы",
                    "В базе: " + count + " товаров\n" +
                            "Проверьте консоль для подробностей");

        } catch (Exception e) {
            System.err.println("Ошибка при проверке БД: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка",
                    "Не удалось проверить базу данных: " + e.getMessage());
        }
    }


    @FXML
    private void testPriceSearch() {
        System.out.println("=== ТЕСТ ПОИСКА ПО ЦЕНЕ ===");

        // Тест 1: Все товары от 0 до 100 рублей
        System.out.println("\n1. Поиск товаров от 0 до 100 руб:");
        minPriceField.setText("0");
        maxPriceField.setText("100");
        nameField.clear();
        categoryComboBox.setValue("");
        minQuantityField.clear();
        statusComboBox.setValue("Все");
        handleSearch();

        // Тест 2: Все товары от 50 рублей
        System.out.println("\n2. Поиск товаров от 50 руб:");
        minPriceField.setText("50");
        maxPriceField.clear();
        handleSearch();

        // Тест 3: Все товары до 200 рублей
        System.out.println("\n3. Поиск товаров до 200 руб:");
        minPriceField.clear();
        maxPriceField.setText("200");
        handleSearch();
    }

    @FXML
    private void handleReset() {
        System.out.println("=== DEBUG: Сброс фильтров ===");

        // Очистка полей
        nameField.clear();
        categoryComboBox.setValue("");
        minPriceField.clear();
        maxPriceField.clear();
        minQuantityField.clear();
        statusComboBox.setValue("Активные");

        // Очистка результатов
        searchResults.clear();

        // Показать сообщение
        showAlert(Alert.AlertType.INFORMATION, "Сброс фильтров",
                "Все фильтры сброшены. Таблица очищена.");

        System.out.println("=== DEBUG: Фильтры сброшены ===");
    }

    private void checkPriceData() {
        System.out.println("=== ПРОВЕРКА ЦЕН В БАЗЕ ===");

        try {
            // Получаем все товары
            List<Product> allProducts = productDao.findAll();

            if (allProducts.isEmpty()) {
                System.out.println("В базе нет товаров!");
                showAlert(Alert.AlertType.WARNING, "Проверка цен", "В базе данных нет товаров!");
                return;
            }

            // Статистика по ценам (используем BigDecimal для точности)
            BigDecimal minPrice = new BigDecimal(Double.MAX_VALUE);
            BigDecimal maxPrice = new BigDecimal(Double.MIN_VALUE);
            BigDecimal total = BigDecimal.ZERO;

            System.out.println("Цены товаров в базе:");
            for (Product p : allProducts) {
                BigDecimal price = p.getPrice();
                if (price == null) {
                    System.out.println("  - " + p.getName() + ": цена не указана");
                    continue;
                }

                System.out.println("  - " + p.getName() + ": " + price + " руб." +
                        " [Категория: " + (p.getCategory() != null ? p.getCategory().getName() : "нет") + "]");

                // Сравнение BigDecimal
                if (price.compareTo(minPrice) < 0) minPrice = price;
                if (price.compareTo(maxPrice) > 0) maxPrice = price;
                total = total.add(price);
            }

            // Вычисляем среднюю цену
            BigDecimal avgPrice = total.divide(new BigDecimal(allProducts.size()), 2, RoundingMode.HALF_UP);

            System.out.println("\nСтатистика цен:");
            System.out.println("  Минимальная цена: " + minPrice + " руб.");
            System.out.println("  Максимальная цена: " + maxPrice + " руб.");
            System.out.println("  Средняя цена: " + avgPrice + " руб.");
            System.out.println("  Всего товаров: " + allProducts.size());

            // Тестируем поиск по цене напрямую
            System.out.println("\n=== ТЕСТ ПОИСКА ПО ЦЕНЕ ===");

            // Тест 1: Все товары
            System.out.println("1. Все товары (без фильтра цены):");
            List<Product> allProductsTest = productDao.findByPriceRange(null, null);
            System.out.println("   Найдено: " + allProductsTest.size() + " товаров");

            // Тест 2: От 0 до средней цены (конвертируем BigDecimal в Double)
            System.out.println("\n2. Товары от 0 до средней цены (" + avgPrice + " руб.):");
            List<Product> cheapProducts = productDao.findByPriceRange(0.0, avgPrice.doubleValue());
            System.out.println("   Найдено: " + cheapProducts.size() + " товаров");
            for (Product p : cheapProducts) {
                System.out.println("     - " + p.getName() + ": " + p.getPrice() + " руб.");
            }

            // Тест 3: От средней цены
            System.out.println("\n3. Товары от средней цены (" + avgPrice + " руб.) и выше:");
            List<Product> expensiveProducts = productDao.findByPriceRange(avgPrice.doubleValue(), null);
            System.out.println("   Найдено: " + expensiveProducts.size() + " товаров");
            for (Product p : expensiveProducts) {
                System.out.println("     - " + p.getName() + ": " + p.getPrice() + " руб.");
            }

            // Показать алерт со статистикой
            showAlert(Alert.AlertType.INFORMATION, "Статистика цен",
                    String.format("Всего товаров: %d\n" +
                                    "Минимальная цена: %s руб.\n" +
                                    "Максимальная цена: %s руб.\n" +
                                    "Средняя цена: %s руб.\n\n" +
                                    "Товаров до %s руб.: %d\n" +
                                    "Товаров от %s руб.: %d",
                            allProducts.size(),
                            minPrice.toString(),
                            maxPrice.toString(),
                            avgPrice.toString(),
                            avgPrice.toString(), cheapProducts.size(),
                            avgPrice.toString(), expensiveProducts.size()));

        } catch (Exception e) {
            System.err.println("Ошибка при проверке цен: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Ошибка",
                    "Не удалось проверить цены: " + e.getMessage());
        }
    }

    private Double parseDouble(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            System.out.println("WARN: Не удалось преобразовать в Double: '" + text + "'");
            return null;
        }
    }

    private Integer parseInteger(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            System.out.println("WARN: Не удалось преобразовать в Integer: '" + text + "'");
            return null;
        }
    }

    private Boolean getActiveFilter() {
        String status = statusComboBox.getValue();
        System.out.println("DEBUG: Статус из ComboBox: '" + status + "'");

        if (status == null || "Все".equals(status)) {
            return null;
        }
        return "Активные".equals(status);
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Добавьте этот метод для отладки - вызывает поиск с пустыми параметрами
    public void testEmptySearch() {
        System.out.println("=== ТЕСТ: Поиск с пустыми параметрами ===");
        handleSearch();
    }
}